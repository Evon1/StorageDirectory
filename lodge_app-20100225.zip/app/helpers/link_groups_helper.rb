module LinkGroupsHelper
end
