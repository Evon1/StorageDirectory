class Suggestion < ActiveRecord::Base
  
  access_shared_methods
  
end
