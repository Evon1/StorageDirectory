-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.1.40


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema thelodgedb
--

CREATE DATABASE IF NOT EXISTS thelodgedb;
USE thelodgedb;

DROP TABLE IF EXISTS `thelodgedb`.`block_forms`;
CREATE TABLE  `thelodgedb`.`block_forms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `block_id` int(11) DEFAULT NULL,
  `form_id` int(11) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`block_forms` (`id`,`block_id`,`form_id`,`enabled`,`position`,`created_at`,`updated_at`) VALUES 
 (6,14,1,1,NULL,'2009-12-29 17:01:32','2009-12-29 17:01:32'),
 (7,6,2,1,NULL,'2010-01-03 03:07:17','2010-01-03 03:07:17'),
 (8,21,6,1,NULL,'2010-01-04 03:56:37','2010-01-04 03:56:37');

DROP TABLE IF EXISTS `thelodgedb`.`block_widgets`;
CREATE TABLE  `thelodgedb`.`block_widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `block_id` int(11) DEFAULT NULL,
  `widget_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=122 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`block_widgets` (`id`,`block_id`,`widget_id`,`created_at`,`updated_at`) VALUES 
 (1,NULL,0,'2009-10-26 03:23:38','2009-12-25 22:04:02'),
 (2,NULL,0,'2009-10-26 03:24:52','2009-10-27 23:43:57'),
 (3,NULL,0,'2009-10-27 23:43:57','2009-10-27 23:47:51'),
 (4,5,1,'2009-10-27 23:47:51','2009-10-27 23:47:51'),
 (5,1,0,'2009-11-08 19:30:37','2009-11-08 19:30:37'),
 (6,NULL,0,'2009-12-24 01:39:05','2009-12-28 08:00:02'),
 (7,NULL,0,'2009-12-24 03:28:07','2009-12-24 22:36:16'),
 (8,NULL,0,'2009-12-24 22:36:16','2009-12-24 22:37:14'),
 (9,NULL,0,'2009-12-24 22:37:14','2009-12-24 22:39:32'),
 (10,NULL,0,'2009-12-24 22:39:32','2009-12-26 16:45:26'),
 (11,NULL,0,'2009-12-25 22:04:02','2009-12-25 22:10:34'),
 (12,NULL,0,'2009-12-25 22:10:34','2009-12-25 23:11:35'),
 (13,NULL,0,'2009-12-25 23:11:35','2009-12-25 23:12:32'),
 (14,NULL,0,'2009-12-25 23:12:32','2009-12-26 07:15:46'),
 (15,NULL,0,'2009-12-25 23:40:19','2009-12-25 23:40:35'),
 (16,NULL,0,'2009-12-25 23:40:35','2009-12-25 23:41:38'),
 (17,NULL,0,'2009-12-25 23:41:38','2009-12-26 01:11:10'),
 (18,NULL,0,'2009-12-26 01:44:32','2009-12-26 02:01:30'),
 (19,NULL,0,'2009-12-26 02:01:30','2009-12-26 02:04:16'),
 (20,NULL,0,'2009-12-26 02:04:16','2009-12-26 02:04:28'),
 (21,NULL,0,'2009-12-26 02:04:28','2009-12-26 02:39:45'),
 (22,NULL,0,'2009-12-26 02:39:45','2009-12-26 07:28:16'),
 (23,NULL,0,'2009-12-26 03:09:55','2009-12-26 17:59:16'),
 (24,NULL,0,'2009-12-26 03:13:25','2009-12-26 07:28:41'),
 (25,NULL,0,'2009-12-26 07:15:46','2009-12-28 08:20:43'),
 (26,NULL,0,'2009-12-26 07:28:16','2009-12-26 19:05:10'),
 (27,NULL,0,'2009-12-26 07:28:41','2009-12-26 07:34:41'),
 (28,NULL,0,'2009-12-26 07:34:41','2009-12-26 07:42:41'),
 (29,NULL,0,'2009-12-26 07:42:41','2009-12-26 18:59:28'),
 (30,NULL,0,'2009-12-26 16:45:26','2009-12-26 17:50:04'),
 (31,NULL,0,'2009-12-26 17:50:04','2010-01-03 12:03:51'),
 (32,NULL,0,'2009-12-26 17:59:16','2009-12-26 17:59:18'),
 (33,NULL,0,'2009-12-26 17:59:18','2009-12-26 18:17:43'),
 (34,8,0,'2009-12-26 18:17:43','2009-12-26 18:17:43'),
 (35,NULL,0,'2009-12-26 18:59:28','2009-12-28 09:06:16'),
 (36,NULL,0,'2009-12-26 19:05:10','2009-12-26 19:18:39'),
 (37,NULL,0,'2009-12-26 19:18:39','2009-12-26 19:22:09'),
 (38,NULL,0,'2009-12-26 19:22:09','2009-12-26 19:22:37'),
 (39,NULL,0,'2009-12-26 19:22:37','2009-12-26 19:34:04'),
 (40,NULL,0,'2009-12-26 19:34:04','2009-12-26 19:35:50'),
 (41,NULL,0,'2009-12-26 19:35:50','2009-12-28 08:03:30'),
 (42,NULL,0,'2009-12-28 02:21:48','2009-12-28 08:15:01'),
 (43,NULL,0,'2009-12-28 04:58:59','2009-12-28 05:05:55'),
 (44,13,0,'2009-12-28 05:05:55','2009-12-28 05:05:55'),
 (45,NULL,0,'2009-12-28 06:45:21','2009-12-28 07:15:31'),
 (46,NULL,0,'2009-12-28 07:15:31','2009-12-28 07:18:14'),
 (47,NULL,0,'2009-12-28 07:18:14','2009-12-28 07:19:04'),
 (48,NULL,0,'2009-12-28 07:19:04','2009-12-28 07:29:15'),
 (49,NULL,0,'2009-12-28 07:29:15','2009-12-28 07:52:07'),
 (50,NULL,0,'2009-12-28 07:52:07','2009-12-29 16:52:25'),
 (51,NULL,0,'2009-12-28 08:00:02','2009-12-29 14:11:24'),
 (52,NULL,0,'2009-12-28 08:03:30','2010-01-07 07:12:18'),
 (53,NULL,0,'2009-12-28 08:08:36','2009-12-28 08:09:00'),
 (54,NULL,0,'2009-12-28 08:09:00','2009-12-28 08:10:38'),
 (55,NULL,0,'2009-12-28 08:10:38','2009-12-28 09:33:21'),
 (56,10,0,'2009-12-28 08:15:01','2009-12-28 08:15:01'),
 (57,NULL,0,'2009-12-28 08:20:43','2009-12-28 09:38:05'),
 (58,NULL,0,'2009-12-28 09:02:29','2010-01-03 07:01:29'),
 (59,NULL,0,'2009-12-28 09:12:30','2009-12-28 09:13:24'),
 (60,NULL,0,'2009-12-28 09:13:24','2009-12-28 09:16:57'),
 (61,NULL,0,'2009-12-28 09:16:57','2009-12-28 09:18:46'),
 (62,NULL,0,'2009-12-28 09:18:46','2009-12-30 07:18:40'),
 (63,NULL,0,'2009-12-28 09:33:21','2009-12-28 09:34:32'),
 (64,NULL,0,'2009-12-28 09:34:32','2009-12-28 09:35:38'),
 (65,15,0,'2009-12-28 09:35:38','2009-12-28 09:35:38'),
 (66,NULL,0,'2009-12-28 09:38:05','2009-12-29 05:59:29'),
 (67,NULL,0,'2009-12-28 09:57:51','2009-12-29 02:24:31'),
 (68,NULL,0,'2009-12-29 02:24:31','2009-12-29 02:24:41'),
 (69,17,0,'2009-12-29 02:25:13','2009-12-29 02:25:13'),
 (70,18,0,'2009-12-29 04:13:06','2009-12-29 04:13:06'),
 (71,19,0,'2009-12-29 05:19:14','2009-12-29 05:19:14'),
 (72,4,0,'2009-12-29 05:59:29','2009-12-29 05:59:29'),
 (73,20,1,'2009-12-29 08:52:26','2009-12-29 08:52:26'),
 (74,NULL,0,'2009-12-29 14:11:24','2009-12-29 14:28:47'),
 (75,NULL,0,'2009-12-29 14:28:47','2009-12-29 14:56:43'),
 (76,NULL,0,'2009-12-29 14:56:43','2009-12-29 14:57:28'),
 (77,NULL,0,'2009-12-29 14:57:28','2009-12-29 15:00:26'),
 (78,NULL,0,'2009-12-29 15:00:26','2009-12-29 15:05:49'),
 (79,NULL,0,'2009-12-29 15:05:49','2009-12-29 15:06:09'),
 (80,NULL,0,'2009-12-29 15:06:09','2009-12-29 15:13:18'),
 (81,NULL,0,'2009-12-29 15:13:18','2009-12-29 15:13:28'),
 (82,NULL,0,'2009-12-29 15:13:28','2009-12-29 16:00:03'),
 (83,NULL,0,'2009-12-29 16:00:03','2009-12-29 16:02:10'),
 (84,NULL,0,'2009-12-29 16:02:10','2009-12-29 16:02:41'),
 (85,NULL,0,'2009-12-29 16:02:41','2009-12-29 16:04:29'),
 (86,NULL,0,'2009-12-29 16:04:29','2010-01-03 03:07:17'),
 (87,NULL,0,'2009-12-29 16:52:25','2009-12-29 16:53:10'),
 (88,NULL,0,'2009-12-29 16:53:10','2009-12-29 16:53:19'),
 (89,NULL,0,'2009-12-29 16:53:19','2009-12-29 16:55:56'),
 (90,NULL,0,'2009-12-29 16:55:56','2009-12-29 16:57:11'),
 (91,NULL,0,'2009-12-29 16:57:11','2009-12-29 16:59:27'),
 (92,NULL,0,'2009-12-29 16:59:27','2009-12-29 16:59:42'),
 (93,NULL,0,'2009-12-29 16:59:42','2009-12-29 17:01:21'),
 (94,NULL,0,'2009-12-29 17:01:21','2009-12-29 17:01:32'),
 (95,NULL,0,'2009-12-29 17:01:32','2009-12-29 17:05:01'),
 (96,NULL,0,'2009-12-29 17:05:02','2009-12-29 17:05:41'),
 (97,NULL,0,'2009-12-29 17:05:41','2009-12-29 23:11:08'),
 (98,NULL,0,'2009-12-29 23:11:08','2010-01-03 07:16:01'),
 (99,NULL,0,'2009-12-30 07:18:40','2009-12-30 07:19:38'),
 (100,9,0,'2009-12-30 07:19:38','2009-12-30 07:19:38'),
 (101,6,0,'2010-01-03 03:07:17','2010-01-03 03:07:17'),
 (102,NULL,0,'2010-01-03 07:01:29','2010-01-03 07:02:15'),
 (103,NULL,0,'2010-01-03 07:02:15','2010-01-03 08:23:29'),
 (104,14,0,'2010-01-03 07:16:01','2010-01-03 07:16:01'),
 (105,NULL,0,'2010-01-03 08:23:29','2010-01-03 08:24:52'),
 (106,NULL,0,'2010-01-03 08:24:52','2010-01-03 08:26:57'),
 (107,NULL,0,'2010-01-03 08:26:57','2010-01-03 08:30:41'),
 (108,NULL,0,'2010-01-03 08:30:41','2010-01-03 08:35:38'),
 (109,NULL,0,'2010-01-03 08:35:38','2010-01-03 08:35:53'),
 (110,NULL,0,'2010-01-03 08:35:53','2010-01-03 09:54:36'),
 (111,NULL,0,'2010-01-03 09:54:36','2010-02-21 08:48:50'),
 (112,NULL,0,'2010-01-03 12:03:51','2010-01-03 18:01:03'),
 (113,NULL,0,'2010-01-03 18:01:03','2010-02-21 08:40:15'),
 (114,NULL,0,'2010-01-04 03:56:37','2010-01-04 04:06:54'),
 (115,21,0,'2010-01-04 04:06:54','2010-01-04 04:06:54'),
 (116,7,0,'2010-01-07 07:12:18','2010-01-07 07:12:18'),
 (117,NULL,0,'2010-02-21 08:40:15','2010-02-21 09:01:06'),
 (118,NULL,0,'2010-02-21 08:48:50','2010-02-21 08:49:34'),
 (119,16,0,'2010-02-21 08:49:34','2010-02-21 08:49:34'),
 (120,NULL,0,'2010-02-21 09:01:06','2010-02-21 09:01:13'),
 (121,2,0,'2010-02-21 09:01:13','2010-02-21 09:01:13');

DROP TABLE IF EXISTS `thelodgedb`.`blocks`;
CREATE TABLE  `thelodgedb`.`blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `content` text,
  `show_title` tinyint(1) DEFAULT NULL,
  `show_in_all` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`blocks` (`id`,`created_at`,`updated_at`,`title`,`description`,`content`,`show_title`,`show_in_all`) VALUES 
 (2,'2009-10-22 02:26:42','2010-02-21 09:01:06','Footer','HTML for the footer.','<div id=\"twitter\"><img src=\"/images/ui/thelodgedb/twitter-icon.png\" alt=\"Follow Us on Twitter\" /></div>\r\n					<div id=\"specials\">For Specials and Info Text <h4>LODGE</h4> to 098098</div>\r\n					<div id=\"facebook\"><img src=\"/images/ui/thelodgedb/fb-icon.png\" alt=\"Find Us on Facebook\" /></div>',0,'footer'),
 (5,'2009-10-26 03:24:52','2009-10-28 04:09:18','Randomness','Whataya think?','',NULL,NULL),
 (6,'2009-12-24 01:39:05','2009-12-29 14:11:24','Contact Form','Small contact form','',0,'left'),
 (7,'2009-12-25 23:40:19','2009-12-26 19:05:10','Images','show the images view','',0,''),
 (14,'2009-12-28 06:45:21','2009-12-29 23:11:08','Comments','show the comments view','<a name=\"comments\"></a>',0,''),
 (15,'2009-12-28 08:08:36','2009-12-28 09:35:38','Promotions','Show promotions on all pages','<div class=\"uncollapse\">\r\n	<h4 class=\"left center_line\">\r\n		10% OFF First Project/Service</h4>\r\n	<div class=\"right\">\r\n		<ul class=\"center_line\">\r\n			<li>\r\n				Free Consultation</li>\r\n			<li>\r\n				1 Month Free Support</li>\r\n		</ul>\r\n	</div>\r\n</div>\r\n',0,'column_5'),
 (16,'2009-12-28 09:02:29','2010-02-21 08:49:34','Header','Site logo and address','<h1 id=\"logo\" class=\"accessible_img_link\"><a href=\"#\">The Lodge Beer &amp; Grill</a></h1>\r\n  				<div id=\"address\" class=\"right white\">200 S Federal Highway Boca Raton, FL</div>',0,'header'),
 (17,'2009-12-28 09:57:51','2009-12-28 09:57:51','Diego\'s Blog','block of diego\'s blog view','',0,''),
 (18,'2009-12-29 04:13:06','2009-12-29 04:13:06','SubnavLinksBlock','Shows the view of the links from the SubnavLinks group','',0,'sidebar'),
 (19,'2009-12-29 05:19:14','2009-12-29 05:19:14','Lucho\'s blog block','Lucho\'s blog block','',0,''),
 (20,'2009-12-29 08:52:26','2009-12-29 08:52:26','SlideShow','slideshow block','',0,''),
 (21,'2010-01-04 03:56:37','2010-01-04 03:56:37','PostTagger','Post tag form','',0,'');

DROP TABLE IF EXISTS `thelodgedb`.`blocks_models`;
CREATE TABLE  `thelodgedb`.`blocks_models` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_id` int(11) DEFAULT NULL,
  `model_type` varchar(255) DEFAULT NULL,
  `block_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `place` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `show_title` tinyint(1) DEFAULT NULL,
  `position` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=219 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`blocks_models` (`id`,`model_id`,`model_type`,`block_id`,`created_at`,`updated_at`,`place`,`enabled`,`show_title`,`position`) VALUES 
 (25,1,'Page',5,'2009-12-24 03:26:23','2009-12-29 03:14:40','',0,0,0),
 (27,1,'Page',7,'2009-12-26 02:06:40','2010-02-21 08:52:18','content_bottom',0,1,0),
 (28,1,'Page',NULL,'2009-12-26 02:23:50','2009-12-26 02:23:50','sidebar',NULL,NULL,0),
 (29,1,'Page',NULL,'2009-12-26 02:23:50','2009-12-26 02:23:50','footer',NULL,NULL,0),
 (30,1,'Page',NULL,'2009-12-26 02:23:50','2009-12-26 02:23:50','sidebar',NULL,NULL,0),
 (31,1,'Page',NULL,'2009-12-26 02:23:50','2009-12-26 02:23:50','right',NULL,NULL,0),
 (32,1,'Page',NULL,'2009-12-26 02:23:50','2009-12-26 02:23:50','sidebar',NULL,NULL,0),
 (33,1,'Page',NULL,'2009-12-26 02:23:50','2009-12-26 02:23:50','left',NULL,NULL,0),
 (34,1,'Page',NULL,'2009-12-26 02:23:50','2009-12-26 02:23:50','content_bottom',NULL,NULL,0),
 (35,1,'Page',NULL,'2009-12-26 02:26:12','2009-12-26 02:26:12','content_bottom',NULL,NULL,0),
 (40,2,'Post',5,'2009-12-26 02:48:58','2009-12-26 02:48:58',NULL,0,0,0),
 (59,1,'Post',5,'2009-12-28 06:46:06','2009-12-28 06:58:00','',0,0,0),
 (66,1,'Post',14,'2009-12-28 06:46:06','2009-12-28 07:29:33','content_bottom',1,1,0),
 (84,1,'Page',17,'2009-12-29 03:14:40','2009-12-29 03:20:58','',0,0,0),
 (91,3,'Post',5,'2009-12-29 05:05:47','2009-12-29 05:05:47','',0,0,0),
 (95,3,'Post',14,'2009-12-29 05:05:47','2009-12-29 23:13:02','content_bottom',1,0,0),
 (96,3,'Post',17,'2009-12-29 05:05:47','2009-12-29 05:05:47','',0,0,0),
 (98,3,'Post',19,'2009-12-29 05:21:51','2009-12-29 05:21:51','',0,0,0),
 (99,1,'Post',NULL,'2009-12-29 20:22:15','2009-12-29 20:22:15',NULL,0,NULL,0),
 (100,1,'Post',NULL,'2009-12-29 20:22:15','2009-12-29 20:22:15',NULL,0,NULL,0),
 (101,1,'Post',NULL,'2009-12-29 20:22:15','2009-12-29 20:22:15',NULL,0,NULL,0),
 (102,1,'Post',NULL,'2009-12-29 20:22:15','2009-12-29 20:22:15',NULL,0,NULL,0),
 (103,1,'Post',NULL,'2009-12-29 20:22:15','2009-12-29 20:22:15',NULL,0,NULL,0),
 (104,1,'Post',NULL,'2009-12-29 20:22:15','2009-12-29 20:22:15',NULL,0,NULL,0),
 (105,2,'Post',NULL,'2009-12-29 22:34:26','2009-12-29 22:34:26',NULL,0,NULL,0),
 (106,2,'Post',NULL,'2009-12-29 22:34:26','2009-12-29 22:34:26',NULL,0,NULL,0),
 (107,2,'Post',NULL,'2009-12-29 22:34:26','2009-12-29 22:34:26',NULL,0,NULL,0),
 (108,2,'Post',NULL,'2009-12-29 22:34:26','2009-12-29 22:34:26',NULL,0,NULL,0),
 (109,2,'Post',14,'2009-12-29 22:34:26','2010-01-04 04:07:49','content_bottom',0,0,0),
 (110,2,'Post',NULL,'2009-12-29 22:34:26','2009-12-29 22:34:26',NULL,0,NULL,0),
 (111,2,'Post',NULL,'2009-12-29 22:34:26','2009-12-29 22:34:26',NULL,0,NULL,0),
 (112,2,'Post',NULL,'2009-12-29 22:34:26','2009-12-29 22:34:26',NULL,0,NULL,0),
 (113,3,'Post',NULL,'2009-12-29 23:13:02','2009-12-29 23:13:02',NULL,0,NULL,0),
 (114,3,'Post',NULL,'2009-12-29 23:13:02','2009-12-29 23:13:02',NULL,0,NULL,0),
 (115,3,'Post',NULL,'2009-12-29 23:13:02','2009-12-29 23:13:02',NULL,0,NULL,0),
 (116,3,'Post',NULL,'2009-12-29 23:13:02','2009-12-29 23:13:02',NULL,0,NULL,0),
 (117,3,'Post',NULL,'2009-12-29 23:13:02','2009-12-29 23:13:02',NULL,0,NULL,0),
 (118,3,'Post',NULL,'2009-12-29 23:13:02','2009-12-29 23:13:02',NULL,0,NULL,0),
 (119,3,'Post',NULL,'2009-12-29 23:13:02','2009-12-29 23:13:02',NULL,0,NULL,0),
 (120,1,'Page',NULL,'2009-12-30 07:39:59','2009-12-30 07:39:59',NULL,0,NULL,0),
 (121,1,'Page',NULL,'2009-12-30 07:39:59','2009-12-30 07:39:59',NULL,0,NULL,0),
 (122,1,'Page',NULL,'2009-12-30 07:39:59','2009-12-30 07:39:59',NULL,0,NULL,0),
 (123,1,'Page',NULL,'2009-12-30 07:39:59','2009-12-30 07:39:59',NULL,0,NULL,0),
 (124,1,'Page',NULL,'2009-12-30 07:39:59','2009-12-30 07:39:59',NULL,0,NULL,0),
 (125,1,'Page',NULL,'2009-12-30 07:39:59','2009-12-30 07:39:59',NULL,0,NULL,0),
 (126,1,'Post',NULL,'2009-12-30 07:53:02','2009-12-30 07:53:02',NULL,0,NULL,0),
 (127,1,'Post',NULL,'2009-12-30 07:53:02','2009-12-30 07:53:02',NULL,0,NULL,0),
 (128,1,'Post',NULL,'2009-12-30 07:53:02','2009-12-30 07:53:02',NULL,0,NULL,0),
 (129,1,'Post',NULL,'2009-12-30 07:53:02','2009-12-30 07:53:02',NULL,0,NULL,0),
 (130,1,'Post',NULL,'2009-12-30 07:53:02','2009-12-30 07:53:02',NULL,0,NULL,0),
 (131,1,'Post',NULL,'2009-12-30 07:53:02','2009-12-30 07:53:02',NULL,0,NULL,0),
 (140,2,'Post',NULL,'2010-01-03 07:16:38','2010-01-03 07:16:38',NULL,0,NULL,0),
 (141,2,'Post',NULL,'2010-01-03 07:16:38','2010-01-03 07:16:38',NULL,0,NULL,0),
 (142,2,'Post',NULL,'2010-01-03 07:16:38','2010-01-03 07:16:38',NULL,0,NULL,0),
 (143,2,'Post',NULL,'2010-01-03 07:16:38','2010-01-03 07:16:38',NULL,0,NULL,0),
 (144,2,'Post',NULL,'2010-01-03 07:16:38','2010-01-03 07:16:38',NULL,0,NULL,0),
 (145,2,'Post',NULL,'2010-01-03 07:16:38','2010-01-03 07:16:38',NULL,0,NULL,0),
 (146,2,'Post',NULL,'2010-01-03 07:16:38','2010-01-03 07:16:38',NULL,0,NULL,0),
 (147,2,'Post',NULL,'2010-01-03 07:26:27','2010-01-03 07:26:27',NULL,0,NULL,0),
 (148,2,'Post',NULL,'2010-01-03 07:26:27','2010-01-03 07:26:27',NULL,0,NULL,0),
 (149,2,'Post',NULL,'2010-01-03 07:26:27','2010-01-03 07:26:27',NULL,0,NULL,0),
 (150,2,'Post',NULL,'2010-01-03 07:26:27','2010-01-03 07:26:27',NULL,0,NULL,0),
 (151,2,'Post',NULL,'2010-01-03 07:26:27','2010-01-03 07:26:27',NULL,0,NULL,0),
 (152,2,'Post',NULL,'2010-01-03 07:26:27','2010-01-03 07:26:27',NULL,0,NULL,0),
 (153,2,'Post',NULL,'2010-01-03 07:26:27','2010-01-03 07:26:27',NULL,0,NULL,0),
 (154,2,'Post',NULL,'2010-01-03 07:26:50','2010-01-03 07:26:50',NULL,0,NULL,0),
 (155,2,'Post',NULL,'2010-01-03 07:26:50','2010-01-03 07:26:50',NULL,0,NULL,0),
 (156,2,'Post',NULL,'2010-01-03 07:26:50','2010-01-03 07:26:50',NULL,0,NULL,0),
 (157,2,'Post',NULL,'2010-01-03 07:26:50','2010-01-03 07:26:50',NULL,0,NULL,0),
 (158,2,'Post',NULL,'2010-01-03 07:26:50','2010-01-03 07:26:50',NULL,0,NULL,0),
 (159,2,'Post',NULL,'2010-01-03 07:26:50','2010-01-03 07:26:50',NULL,0,NULL,0),
 (160,2,'Post',NULL,'2010-01-03 07:26:50','2010-01-03 07:26:50',NULL,0,NULL,0),
 (161,2,'Post',NULL,'2010-01-03 07:29:57','2010-01-03 07:29:57',NULL,0,NULL,0),
 (162,2,'Post',NULL,'2010-01-03 07:29:57','2010-01-03 07:29:57',NULL,0,NULL,0),
 (163,2,'Post',NULL,'2010-01-03 07:29:57','2010-01-03 07:29:57',NULL,0,NULL,0),
 (164,2,'Post',NULL,'2010-01-03 07:29:57','2010-01-03 07:29:57',NULL,0,NULL,0),
 (165,2,'Post',NULL,'2010-01-03 07:29:57','2010-01-03 07:29:57',NULL,0,NULL,0),
 (166,2,'Post',NULL,'2010-01-03 07:29:57','2010-01-03 07:29:57',NULL,0,NULL,0),
 (167,2,'Post',NULL,'2010-01-03 07:29:57','2010-01-03 07:29:57',NULL,0,NULL,0),
 (168,2,'Post',NULL,'2010-01-04 04:07:49','2010-01-04 04:07:49',NULL,0,NULL,0),
 (169,2,'Post',NULL,'2010-01-04 04:07:49','2010-01-04 04:07:49',NULL,0,NULL,0),
 (170,2,'Post',NULL,'2010-01-04 04:07:49','2010-01-04 04:07:49',NULL,0,NULL,0),
 (171,2,'Post',NULL,'2010-01-04 04:07:49','2010-01-04 04:07:49',NULL,0,NULL,0),
 (172,2,'Post',NULL,'2010-01-04 04:07:49','2010-01-04 04:07:49',NULL,0,NULL,0),
 (173,2,'Post',NULL,'2010-01-04 04:07:49','2010-01-04 04:07:49',NULL,0,NULL,0),
 (174,2,'Post',NULL,'2010-01-04 04:07:49','2010-01-04 04:07:49',NULL,0,NULL,0),
 (175,2,'Post',NULL,'2010-01-04 04:07:49','2010-01-04 04:07:49',NULL,0,NULL,0),
 (176,2,'Post',NULL,'2010-01-04 04:08:15','2010-01-04 04:08:15',NULL,0,NULL,0),
 (177,2,'Post',NULL,'2010-01-04 04:08:15','2010-01-04 04:08:15',NULL,0,NULL,0),
 (178,2,'Post',NULL,'2010-01-04 04:08:15','2010-01-04 04:08:15',NULL,0,NULL,0),
 (179,2,'Post',NULL,'2010-01-04 04:08:15','2010-01-04 04:08:15',NULL,0,NULL,0),
 (180,2,'Post',NULL,'2010-01-04 04:08:15','2010-01-04 04:08:15',NULL,0,NULL,0),
 (181,2,'Post',NULL,'2010-01-04 04:08:15','2010-01-04 04:08:15',NULL,0,NULL,0),
 (182,2,'Post',NULL,'2010-01-04 04:08:15','2010-01-04 04:08:15',NULL,0,NULL,0),
 (183,2,'Post',NULL,'2010-01-04 04:08:15','2010-01-04 04:08:15',NULL,0,NULL,0),
 (184,2,'Post',21,'2010-01-04 04:08:15','2010-01-04 04:08:15','content_bottom',1,0,0),
 (185,1,'Page',NULL,'2010-02-21 08:52:18','2010-02-21 08:52:18',NULL,0,NULL,0),
 (186,1,'Page',NULL,'2010-02-21 08:52:18','2010-02-21 08:52:18',NULL,0,NULL,0),
 (187,1,'Page',NULL,'2010-02-21 08:52:18','2010-02-21 08:52:18',NULL,0,NULL,0),
 (188,1,'Page',NULL,'2010-02-21 08:52:18','2010-02-21 08:52:18',NULL,0,NULL,0),
 (189,1,'Page',NULL,'2010-02-21 08:52:18','2010-02-21 08:52:18',NULL,0,NULL,0),
 (190,1,'Page',NULL,'2010-02-21 08:52:18','2010-02-21 08:52:18',NULL,0,NULL,0),
 (191,1,'Page',NULL,'2010-02-21 08:58:53','2010-02-21 08:58:53',NULL,0,NULL,0),
 (192,1,'Page',NULL,'2010-02-21 08:58:53','2010-02-21 08:58:53',NULL,0,NULL,0),
 (193,1,'Page',NULL,'2010-02-21 08:58:53','2010-02-21 08:58:53',NULL,0,NULL,0),
 (194,1,'Page',NULL,'2010-02-21 08:58:53','2010-02-21 08:58:53',NULL,0,NULL,0),
 (195,1,'Page',NULL,'2010-02-21 08:58:53','2010-02-21 08:58:53',NULL,0,NULL,0),
 (196,1,'Page',NULL,'2010-02-21 08:58:53','2010-02-21 08:58:53',NULL,0,NULL,0),
 (197,1,'Page',NULL,'2010-02-21 08:58:53','2010-02-21 08:58:53',NULL,0,NULL,0),
 (198,1,'Page',NULL,'2010-02-21 08:59:05','2010-02-21 08:59:05',NULL,0,NULL,0),
 (199,1,'Page',NULL,'2010-02-21 08:59:05','2010-02-21 08:59:05',NULL,0,NULL,0),
 (200,1,'Page',NULL,'2010-02-21 08:59:05','2010-02-21 08:59:05',NULL,0,NULL,0),
 (201,1,'Page',NULL,'2010-02-21 08:59:05','2010-02-21 08:59:05',NULL,0,NULL,0),
 (202,1,'Page',NULL,'2010-02-21 08:59:05','2010-02-21 08:59:05',NULL,0,NULL,0),
 (203,1,'Page',NULL,'2010-02-21 08:59:05','2010-02-21 08:59:05',NULL,0,NULL,0),
 (204,1,'Page',NULL,'2010-02-21 08:59:05','2010-02-21 08:59:05',NULL,0,NULL,0),
 (205,1,'Page',NULL,'2010-02-21 09:13:58','2010-02-21 09:13:58',NULL,0,NULL,0),
 (206,1,'Page',NULL,'2010-02-21 09:13:58','2010-02-21 09:13:58',NULL,0,NULL,0),
 (207,1,'Page',NULL,'2010-02-21 09:13:58','2010-02-21 09:13:58',NULL,0,NULL,0),
 (208,1,'Page',NULL,'2010-02-21 09:13:58','2010-02-21 09:13:58',NULL,0,NULL,0),
 (209,1,'Page',NULL,'2010-02-21 09:13:58','2010-02-21 09:13:58',NULL,0,NULL,0),
 (210,1,'Page',NULL,'2010-02-21 09:13:58','2010-02-21 09:13:58',NULL,0,NULL,0),
 (211,1,'Page',NULL,'2010-02-21 09:13:58','2010-02-21 09:13:58',NULL,0,NULL,0),
 (212,1,'Page',NULL,'2010-02-21 09:17:12','2010-02-21 09:17:12',NULL,0,NULL,0),
 (213,1,'Page',NULL,'2010-02-21 09:17:12','2010-02-21 09:17:12',NULL,0,NULL,0),
 (214,1,'Page',NULL,'2010-02-21 09:17:12','2010-02-21 09:17:12',NULL,0,NULL,0),
 (215,1,'Page',NULL,'2010-02-21 09:17:12','2010-02-21 09:17:12',NULL,0,NULL,0),
 (216,1,'Page',NULL,'2010-02-21 09:17:12','2010-02-21 09:17:12',NULL,0,NULL,0),
 (217,1,'Page',NULL,'2010-02-21 09:17:12','2010-02-21 09:17:12',NULL,0,NULL,0),
 (218,1,'Page',NULL,'2010-02-21 09:17:12','2010-02-21 09:17:12',NULL,0,NULL,0);

DROP TABLE IF EXISTS `thelodgedb`.`comments`;
CREATE TABLE  `thelodgedb`.`comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT '',
  `comment` varchar(255) DEFAULT '',
  `created_at` datetime NOT NULL,
  `commentable_id` int(11) NOT NULL DEFAULT '0',
  `commentable_type` varchar(15) NOT NULL DEFAULT '',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comments_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`comments` (`id`,`title`,`comment`,`created_at`,`commentable_id`,`commentable_type`,`user_id`,`email`) VALUES 
 (1,'i agree','you effin rock yo','2009-12-28 06:24:46',1,'Post',1,NULL),
 (2,'you suck','alot','2009-12-29 05:23:09',3,'Post',0,NULL),
 (9,'magnificent','i like this form. i like it a lot.','2009-12-29 16:10:28',0,'',1,'mastermind@gmail.com'),
 (10,'Just tessin','Wowie wow woW WOWW','2009-12-29 19:46:22',0,'',0,'testing@mail.com'),
 (11,'WooHooo','I think this is gonna rock.','2009-12-29 22:37:08',0,'',1,'hope@thisworks.com'),
 (12,'Does it work? ','How about now?','2009-12-29 23:10:04',2,'Post',1,'me@yea.com'),
 (15,'Oh YEah','Bring it on bitz.','2010-01-03 06:00:24',0,'',1,'mastermind@gmail.com'),
 (19,'Comment on Post: \"Coming Along\"','sweeeetnesssss','2010-01-03 07:36:07',2,'Post',1,'mastermind@gmail.com'),
 (20,'Comment ','wassssuppp','2010-01-03 07:37:24',2,'Post',1,'mastermind@gmail.com'),
 (21,'Comment 0','wooooo','2010-01-03 07:38:45',2,'Post',1,'mastermind@gmail.com'),
 (22,'Nice website','totally slick yo','2010-01-03 08:45:38',0,'',0,'diego@gmail.com'),
 (23,'Whoa','nice pixels','2010-01-03 08:53:17',0,'',0,'me@mail.com'),
 (24,'Comment ','stealing ur dataz son','2010-01-03 08:55:14',1,'Post',0,'hacker@urdataz.com');

DROP TABLE IF EXISTS `thelodgedb`.`fields`;
CREATE TABLE  `thelodgedb`.`fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_type` varchar(255) DEFAULT NULL,
  `field_attributes` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `form_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`fields` (`id`,`field_type`,`field_attributes`,`created_at`,`updated_at`,`form_id`) VALUES 
 (28,'text_field','{\"name\":\"email\",\"title\":\"Your Email\",\"class\":\"email hintable email hintable\"}','2010-01-03 05:18:07','2010-01-03 05:35:21',2),
 (29,'text_field','{\"name\":\"title\",\"title\":\"Subject\",\"class\":\"required hintable required hintable\"}','2010-01-03 05:18:07','2010-01-03 05:35:21',2),
 (30,'text_area','{\"name\":\"comment\",\"title\":\"Message\",\"class\":\"required hintable small_textarea\"}','2010-01-03 05:18:07','2010-01-03 05:36:09',2),
 (37,'text_field','{\"name\":\"email\",\"title\":\"Your Email\",\"class\":\"small_textfield required hintable\"}','2010-01-03 06:12:48','2010-01-03 06:12:48',1),
 (38,'text_area','{\"name\":\"comment\",\"title\":\"Your Thoughts\",\"class\":\"small_textarea required hintable\"}','2010-01-03 06:12:48','2010-01-03 06:12:48',1),
 (39,'text_field','{\"name\":\"name\",\"title\":\"Tags\",\"class\":\"tags_field hintable\"}','2010-01-04 03:42:40','2010-01-04 03:42:40',6);

DROP TABLE IF EXISTS `thelodgedb`.`forms`;
CREATE TABLE  `thelodgedb`.`forms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `controller` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `scope` varchar(255) DEFAULT NULL,
  `target_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`forms` (`id`,`name`,`description`,`controller`,`action`,`enabled`,`created_at`,`updated_at`,`scope`,`target_id`) VALUES 
 (1,'Share your thoughts','The post comment form','comments','create',1,'2009-12-29 11:18:50','2009-12-29 22:33:44','post',NULL),
 (2,'Contact Form','Sitewide contact form','comments','create',1,'2009-12-29 23:28:05','2010-01-03 00:06:28','',NULL),
 (6,'Post Tag Form','Create tags on a post','tags','create',1,'2010-01-02 22:23:52','2010-01-02 22:23:52','post',NULL);

DROP TABLE IF EXISTS `thelodgedb`.`galleries`;
CREATE TABLE  `thelodgedb`.`galleries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`galleries` (`id`,`title`,`created_at`,`updated_at`,`description`) VALUES 
 (1,'Kitesurfing','2009-10-26 06:29:16','2009-10-26 06:29:16','Kitesurfing pics'),
 (2,'Stuff','2009-10-28 01:25:02','2009-10-28 01:25:02','random pics for your enjoyment');

DROP TABLE IF EXISTS `thelodgedb`.`gallery_images`;
CREATE TABLE  `thelodgedb`.`gallery_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gallery_id` int(11) DEFAULT NULL,
  `image_id` int(11) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`gallery_images` (`id`,`gallery_id`,`image_id`,`order`,`created_at`,`updated_at`) VALUES 
 (2,1,12,NULL,'2009-10-27 02:27:57','2009-10-27 02:27:57'),
 (3,1,13,NULL,'2009-10-27 02:28:17','2009-10-27 02:28:17'),
 (4,1,14,NULL,'2009-10-27 02:31:18','2009-10-27 02:31:18'),
 (5,1,15,NULL,'2009-10-27 02:34:48','2009-10-27 02:34:48'),
 (6,1,16,NULL,'2009-10-27 02:40:12','2009-10-27 02:40:12'),
 (8,1,18,NULL,'2009-10-27 03:23:29','2009-10-27 03:23:29'),
 (9,2,19,NULL,'2009-10-28 01:25:20','2009-10-28 01:25:20'),
 (10,2,20,NULL,'2009-10-28 01:25:39','2009-10-28 01:25:39'),
 (11,2,21,NULL,'2009-10-28 01:26:03','2009-10-28 01:26:03'),
 (12,2,22,NULL,'2009-10-28 01:26:46','2009-10-28 01:26:46'),
 (13,2,23,NULL,'2009-10-28 01:27:33','2009-10-28 01:27:33'),
 (14,2,24,NULL,'2009-10-28 01:28:04','2009-10-28 01:28:04');

DROP TABLE IF EXISTS `thelodgedb`.`helptexts`;
CREATE TABLE  `thelodgedb`.`helptexts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(255) DEFAULT NULL,
  `text` text,
  `examples` text,
  `show` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`helptexts` (`id`,`model`,`text`,`examples`,`show`,`created_at`,`updated_at`) VALUES 
 (1,'view','Views define what model records to list, and by what scope. Scoping a view retrieves the records of the view\'s\r\nmodel that are owned by either the active instance (e.g. @page, or @block. in the show action of the model) \r\nor a specific instance as defined by the view\'s owner_id.','<p>\r\n	Example 1:<br />\r\n	A view whose model is &#39;comment&#39; will display all comments. Using scope &#39;post&#39; with no owner_id will retrieve the comments that are owned by the active post instance, if the view is placed in a block or page where that instance variable is set (in this case: @post). For this comment example to work we would have to assign the view to a block and place the block in any post. The view will then render that post&#39;s comments.</p>\r\n<p>\r\n	Example 1:<br />\r\n	A view whose model is &#39;post&#39; will display all posts. Using scope &#39;user&#39; and choosing a user from the resulting dropdown menu in th form, will retrieve all the posts of that specific user. We can then place this view anywhere and it will render all posts by that user if he/she exists, otherwise it will render all posts.</p>\r\n',0,'2009-12-28 20:26:24','2009-12-29 06:51:48'),
 (2,'page','<p>\r\n	Pages are the building blocks of the website. You can author static &#39;Content&#39; for simple pages such as &#39;about&#39;, &#39;contact&#39;, etc. Utilize the built in Rich Text Editor by clicking on &#39;Toggle Editor&#39;. Alternatively, and more preferably, you can build dynamic pages using <a href=\"/blocks\" title=\"The building blocks of pages\">blocks</a>. Select &#39;Show in Nav&#39; to have the page appear in the main site navigation. The &#39;Blocks&#39; list displays available blocks to be placed within regions on the page. A block is &#39;available&#39; when it has not been set to &#39;show in all pages&#39; in the block edit form. A region is a spot on the page that contains blocks, e.g. Banner, Header, Subnav, Footer (and more depending on the layout). To place a block in a region, simply enable its check box and choose a region from its dropdown menu. Adjust the order of the blocks by drag-n-dropping them within the list.</p>\r\n','',0,'2009-12-28 22:37:34','2010-02-21 09:02:08'),
 (3,'block','<p>\r\n	These are the building blocks of pages. You can use them to build pages from scratch or to display common content across the website. Blocks can also be placed in posts. At their simplest, blocks contain static HTML and are used to display content that rarely changes on common areas of the website such as the header, sidebar and footer. Blocks have a special feature called <a href=\"/views\" title=\"Views allow you to display your content in various ways\">Views</a> that allow you to customize the way you display your content. Finally, a block may contain a widget. Currently, only the slideshow widget is supported.</p>\r\n','<p>\r\n	Example 1 - Static content: regions like the header, sidebar, and footer rarely change, so blocks with static HTML are used to display content in these regions.</p>\r\n<p>\r\n	Example 2 - Views: A personal blog page can be achieved by creating a view that lists Posts, scoped by User and has a specific user as the Owner. Then, pop this view in a block and place the block in the Content Bottom of any page. The block will now display posts of that user in a configurable way.</p>\r\n<p>\r\n	Example 3 - Widgets: Blocks can be assigned one widget, currently only the slideshow widget is supported. To create a slideshow, assign a gallery to a slideshow widget.</p>\r\n',0,'2009-12-29 02:51:22','2010-02-21 08:39:04'),
 (4,'helptext','If you\'re here, you probably know what you\'re doing.','',0,'2009-12-29 03:08:53','2009-12-29 03:12:37'),
 (5,'user','You are the user.','<p>\r\n	Example 1: You.</p>\r\n<p>\r\n	Example 2: Me.</p>\r\n',0,'2009-12-29 05:45:32','2010-01-03 11:26:06'),
 (6,'comment','Comments can be made on Pages, Posts, Images, and Users. Simply make a form to create comments on any of these resources, assign the form to a block and place it on a page that displays instances of the resource, e.g \"/posts/23\", \"/pages/2\". ','',1,'2010-01-03 12:54:20','2010-01-03 12:54:20');

DROP TABLE IF EXISTS `thelodgedb`.`images`;
CREATE TABLE  `thelodgedb`.`images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `image_file_name` varchar(255) DEFAULT NULL,
  `image_content_type` varchar(255) DEFAULT NULL,
  `image_file_size` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `description` text,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`images` (`id`,`title`,`image_file_name`,`image_content_type`,`image_file_size`,`created_at`,`updated_at`,`user_id`,`description`,`content`) VALUES 
 (12,'Pic1','kite1.jpg','image/jpeg',65813,'2009-10-27 02:27:56','2009-10-27 02:27:56',NULL,NULL,NULL),
 (13,'Pic2','kite2.jpg','image/jpeg',72780,'2009-10-27 02:28:16','2009-10-27 02:28:16',NULL,NULL,NULL),
 (14,'Pic3','kite3.jpg','image/jpeg',64245,'2009-10-27 02:31:17','2009-10-27 02:31:17',NULL,NULL,NULL),
 (15,'Pic4','kite4.jpg','image/jpeg',56154,'2009-10-27 02:34:47','2009-10-27 02:34:47',NULL,NULL,NULL),
 (16,'Pic5','kite5.jpg','image/jpeg',55259,'2009-10-27 02:40:11','2009-10-27 02:40:11',NULL,NULL,NULL),
 (18,'Pic6','kite6.jpg','image/jpeg',70884,'2009-10-27 03:23:28','2009-10-27 03:23:28',NULL,NULL,NULL),
 (19,'Random1','804633.1.jpg','image/jpeg',51375,'2009-10-28 01:25:20','2010-01-07 07:24:02',NULL,'lick it up','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec et lacus leo. Suspendisse a hendrerit est. Fusce pellentesque vestibulum porta. Proin faucibus nulla sed quam malesuada fringilla. Fusce molestie ante sed justo faucibus ut iaculis sem mattis. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Morbi et turpis leo. Pellentesque hendrerit cursus tortor et dignissim.'),
 (20,'Random2','27949870.JPG','image/jpeg',32291,'2009-10-28 01:25:39','2009-10-28 01:25:39',NULL,NULL,NULL),
 (21,'Random3','292198367_360255368f.jpg','image/jpeg',47202,'2009-10-28 01:26:03','2009-10-28 01:26:03',NULL,NULL,NULL),
 (22,'Random4','Escher.jpg','image/jpeg',99640,'2009-10-28 01:26:46','2009-10-28 01:26:46',NULL,NULL,NULL),
 (23,'Random5','cf53_3-1.JPG','image/jpeg',49266,'2009-10-28 01:27:33','2009-10-28 01:27:33',NULL,NULL,NULL),
 (24,'Random6','IMG_6450.jpg','image/jpeg',1437462,'2009-10-28 01:28:04','2009-10-28 01:28:04',NULL,NULL,NULL),
 (29,'my pic','804633.1.jpg','image/jpeg',51375,'2010-01-03 11:36:56','2010-01-03 11:36:56',1,NULL,NULL);

DROP TABLE IF EXISTS `thelodgedb`.`link_groups`;
CREATE TABLE  `thelodgedb`.`link_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`link_groups` (`id`,`name`,`description`,`created_at`,`updated_at`) VALUES 
 (1,'SubnavLinks','Links for the subnav','2009-12-29 03:45:32','2009-12-29 03:45:32');

DROP TABLE IF EXISTS `thelodgedb`.`links`;
CREATE TABLE  `thelodgedb`.`links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `relative` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `link_group_id` int(11) DEFAULT NULL,
  `resource` varchar(255) DEFAULT NULL,
  `target_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`links` (`id`,`title`,`path`,`relative`,`created_at`,`updated_at`,`link_group_id`,`resource`,`target_id`) VALUES 
 (1,'Homebase','Absolute URL',1,'2009-10-24 16:31:35','2010-01-15 06:46:17',1,'page',1),
 (2,'Web Design','Absolute URL',1,'2009-10-24 23:09:55','2010-01-15 06:51:11',1,'page',2),
 (3,'Anotherlink','/anotherlink',1,'2009-10-24 23:10:17','2009-12-29 04:01:47',1,NULL,NULL);

DROP TABLE IF EXISTS `thelodgedb`.`models_views`;
CREATE TABLE  `thelodgedb`.`models_views` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `view_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `model_type` varchar(255) DEFAULT NULL,
  `order` varchar(255) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `limit` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `view_type` varchar(255) DEFAULT NULL,
  `fields` text,
  `enabled` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`models_views` (`id`,`view_id`,`model_id`,`model_type`,`order`,`position`,`limit`,`created_at`,`updated_at`,`view_type`,`fields`,`enabled`) VALUES 
 (3,2,7,'Block','updated_at DESC',NULL,3,'2009-12-26 02:04:28','2010-01-07 07:12:18','blog_roll','id, title, created_at, description, content',1),
 (9,5,17,'Block','updated_at DESC',NULL,NULL,'2009-12-29 02:25:13','2009-12-29 02:25:13','blog_roll','id, title, content, user_id, created_at, comments_count, comments_enabled',NULL),
 (10,6,18,'Block','title ASC',NULL,NULL,'2009-12-29 04:13:06','2009-12-29 04:13:06','list','id, title, path, relative',NULL),
 (11,7,19,'Block','updated_at DESC',NULL,NULL,'2009-12-29 05:19:14','2009-12-29 05:19:14','blog_roll','id, title, content, user_id, updated_at, comments_count',NULL),
 (12,4,14,'Block','created_at DESC',NULL,NULL,'2009-12-29 17:05:41','2010-01-03 07:16:01','blog_roll','id, title, comment, created_at, commentable_id, user_id, email',1),
 (13,9,21,'Block','updated_at DESC',NULL,NULL,'2010-01-04 04:06:54','2010-01-04 04:06:54','list','id, name',1);

DROP TABLE IF EXISTS `thelodgedb`.`pages`;
CREATE TABLE  `thelodgedb`.`pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `show_in_nav` tinyint(1) DEFAULT NULL,
  `content` text,
  `description` text,
  `show_title` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`pages` (`id`,`title`,`parent_id`,`url`,`created_at`,`updated_at`,`show_in_nav`,`content`,`description`,`show_title`) VALUES 
 (1,'Home',NULL,'home/','2009-10-22 01:29:50','2010-02-21 09:13:58',1,'<div class=\"center\">\r\n<h2 class=\"white\">Our Specials</h2>\r\n						<p>\r\n							Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. \r\n							Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure \r\n							dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non \r\n							proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n						</p>\r\n</div>','Content and HTML for the home page.',0);

DROP TABLE IF EXISTS `thelodgedb`.`permissions`;
CREATE TABLE  `thelodgedb`.`permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resource` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `scope` varchar(255) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`permissions` (`id`,`resource`,`action`,`scope`,`role_id`,`created_at`,`updated_at`) VALUES 
 (1,'posts','create',NULL,2,'2010-01-03 23:51:54','2010-01-04 02:57:00'),
 (3,'posts','read',NULL,2,'2010-01-04 02:57:00','2010-01-04 02:57:00');

DROP TABLE IF EXISTS `thelodgedb`.`posts`;
CREATE TABLE  `thelodgedb`.`posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `user_id` int(11) DEFAULT NULL,
  `published` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `comments_count` int(11) DEFAULT '0',
  `comments_enabled` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`posts` (`id`,`title`,`content`,`user_id`,`published`,`created_at`,`updated_at`,`comments_count`,`comments_enabled`) VALUES 
 (1,'Awesomeness','<h3>\r\n	I hope this effin rocks</h3>\r\n<div class=\"rc\">\r\n	<p>\r\n		It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n</div>\r\n',1,1,'2009-11-03 05:26:43','2009-11-06 23:56:21',1,NULL),
 (2,'Coming Along','<h3>\r\n	Its working out great.</h3>\r\n<p style=\"text-align: center;\">\r\n	<img align=\"middle\" alt=\"\" height=\"218\" src=\"http://www.vanessacarpenter.com/img/photo2.gif\" style=\"width: 700px; height: 218px;\" width=\"700\" /></p>\r\n<div id=\"lipsum\">\r\n	<p>\r\n		Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum porta odio et arcu posuere vulputate. Donec congue fringilla lectus id pulvinar. Integer vitae nisi id nisl accumsan placerat. Etiam a metus leo. Morbi tristique lorem at nisi sagittis fermentum. Quisque dignissim lacinia sagittis. Nunc et eros quam. Nullam non ligula tellus. Sed non congue velit. Vivamus aliquam, nisi ac blandit aliquet, arcu turpis viverra mi, nec dapibus est mauris vitae felis.</p>\r\n	<p>\r\n		Sed et semper ante. Fusce vestibulum, enim non adipiscing mattis, est nibh faucibus nunc, eu molestie odio felis id ligula. Donec tempus pellentesque malesuada. Nulla rhoncus vulputate ante, ut feugiat magna laoreet id. Aliquam sollicitudin ante sed odio pretium elementum. Aliquam id dui vitae nulla mattis convallis quis tincidunt nulla. Nunc aliquam lorem vitae mi pretium sit amet fermentum massa fermentum. Fusce libero nisi, ornare pretium placerat vel, tempor vel quam. Nullam dapibus ipsum nec velit semper tristique. Mauris imperdiet risus vitae sem egestas eu iaculis massa condimentum. Sed luctus suscipit dolor sed euismod.</p>\r\n	<p>\r\n		Vestibu<img align=\"left\" alt=\"\" height=\"152\" src=\"http://www.flash-slideshow-maker.com/images/help_clip_image020.jpg\" width=\"200\" />lum ullamcorper gravida tempus. Maecenas feugiat metus sit amet tellus dapibus eu euismod nisl dapibus. Donec a turpis eu nibh porta pretium. Cras venenatis, orci id pretium iaculis, arcu magna scelerisque urna, eu malesuada justo velit a eros. Donec feugiat tincidunt massa cursus congue. Mauris sit amet justo orci, quis ultrices nunc. Nullam volutpat pellentesque rhoncus. Phasellus quis nibh eget massa porta mollis vitae vitae felis. Morbi iaculis pulvinar odio vitae feugiat. Vestibulum mattis odio eget dui tincidunt non viverra tellus venenatis. Curabitur nec nisi ut sem dictum suscipit ut in justo. Donec ac dui sed nibh tincidunt porttitor vel at est. Aliquam erat volutpat. Nulla mollis nisi ac nunc pulvinar placerat. Nunc eu egestas nulla.</p>\r\n	<p>\r\n		<img align=\"right\" alt=\"\" height=\"150\" src=\"http://content.authorstream.com/images/Noormahl-9875-Fantastic-Images-fantastic-pics4177-ppt-powerpoint-118_88.jpg\" width=\"200\" />Praesent elementum adipiscing nulla, non interdum justo suscipit a. Aenean commodo posuere nibh, id blandit erat dictum non. Pellentesque dui nunc, congue vitae eleifend vitae, placerat ac risus. Nulla pulvinar tempus facilisis. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nulla malesuada lorem eget eros congue quis cursus risus venenatis. Duis justo felis, euismod eget interdum a, molestie ac odio. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nunc quis turpis vitae odio commodo fringilla. Curabitur eget iaculis leo. Nam rutrum tempor sem, ac pellentesque odio gravida id. Integer commodo elementum enim eu condimentum. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Etiam fermentum adipiscing commodo. Sed malesuada consequat nibh, non ultrices nibh hendrerit bibendum. Donec ultrices sagittis tellus nec rhoncus. Nullam pellentesque dignissim dignissim.</p>\r\n	<p>\r\n		Cras nulla est, mollis a fermentum aliquet, rutrum non sem. Nulla facilisi. Proin aliquet malesuada convallis. Etiam in quam ut ante vestibulum aliquet non accumsan tortor. Integer tincidunt mattis est, nec interdum nisl porta quis. Cras eleifend justo ut arcu ultrices lobortis. Fusce mauris ligula, pellentesque sit amet tempor quis, auctor ac leo. Quisque nec lorem semper arcu posuere luctus et id velit. Donec urna risus, lacinia vel euismod vel, accumsan sed arcu. Donec nec congue sem. Integer magna magna, lacinia adipiscing semper vel, viverra eu felis. In molestie metus ornare metus volutpat dapibus. Integer hendrerit est faucibus tortor condimentum tempus. Duis vehicula placerat mi egestas eleifend. Vivamus vestibulum ipsum et metus pulvinar a sollicitudin dui malesuada. Proin iaculis lectus eu nunc tempor pellentesque.</p>\r\n</div>\r\n',1,1,'2009-12-26 02:48:58','2009-12-26 02:54:46',0,NULL),
 (3,'Test post.','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sagittis ante sed quam dapibus pellentesque. Sed condimentum rhoncus egestas. Phasellus sagittis lorem sed turpis condimentum vulputate. Vivamus urna libero, ullamcorper in interdum eu, consequat ut felis. Etiam at ultricies neque. Vestibulum faucibus, nibh sit amet aliquet imperdiet, augue metus tempor dolor, in euismod sapien justo a erat. Maecenas elit nisi, dapibus quis dictum sed, luctus id lectus. Duis accumsan lobortis auctor. Nam tempor odio sit amet elit vestibulum nec consequa.',3,1,'2009-12-29 05:05:47','2009-12-29 05:05:47',1,NULL);

DROP TABLE IF EXISTS `thelodgedb`.`roles`;
CREATE TABLE  `thelodgedb`.`roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`roles` (`id`,`title`,`created_at`,`updated_at`) VALUES 
 (1,'Admin','2010-01-03 23:49:31','2010-01-03 23:49:31'),
 (2,'Writer','2010-01-03 23:49:47','2010-01-03 23:49:47'),
 (3,'Subscriber','2010-01-03 23:49:59','2010-01-03 23:49:59');

DROP TABLE IF EXISTS `thelodgedb`.`schema_migrations`;
CREATE TABLE  `thelodgedb`.`schema_migrations` (
  `version` varchar(255) NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`schema_migrations` (`version`) VALUES 
 ('20091014021209'),
 ('20091014225335'),
 ('20091014225552'),
 ('20091014230855'),
 ('20091015195645'),
 ('20091015200226'),
 ('20091015200506'),
 ('20091015200950'),
 ('20091015232818'),
 ('20091022045224'),
 ('20091022055430'),
 ('20091023043448'),
 ('20091024234522'),
 ('20091025194246'),
 ('20091026012136'),
 ('20091026033106'),
 ('20091026044725'),
 ('20091026044840'),
 ('20091026045218'),
 ('20091026050451'),
 ('20091027032613'),
 ('20091101233717'),
 ('20091102010603'),
 ('20091102020639'),
 ('20091103020329'),
 ('20091103021236'),
 ('20091103021509'),
 ('20091103033125'),
 ('20091103035431'),
 ('20091224022844'),
 ('20091225054127'),
 ('20091225073949'),
 ('20091225185949'),
 ('20091225190523'),
 ('20091225191132'),
 ('20091225223106'),
 ('20091226162714'),
 ('20091226163306'),
 ('20091226174507'),
 ('20091226190656'),
 ('20091226232840'),
 ('20091228053428'),
 ('20091228061033'),
 ('20091228063338'),
 ('20091228161508'),
 ('20091228200352'),
 ('20091228233644'),
 ('20091228235420'),
 ('20091229032609'),
 ('20091229033215'),
 ('20091229094516'),
 ('20091229125341'),
 ('20091229133234'),
 ('20091229150821'),
 ('20091229202439'),
 ('20091229205600'),
 ('20091229211742'),
 ('20091230043506'),
 ('20100103015729'),
 ('20100103015807'),
 ('20100103022328'),
 ('20100103022640'),
 ('20100103090350'),
 ('20100103215134'),
 ('20100107070421'),
 ('20100107073354'),
 ('20100115031926'),
 ('20100221085730');

DROP TABLE IF EXISTS `thelodgedb`.`suggestions`;
CREATE TABLE  `thelodgedb`.`suggestions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `controller` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `thelodgedb`.`taggings`;
CREATE TABLE  `thelodgedb`.`taggings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_id` int(11) DEFAULT NULL,
  `taggable_id` int(11) DEFAULT NULL,
  `tagger_id` int(11) DEFAULT NULL,
  `tagger_type` varchar(255) DEFAULT NULL,
  `taggable_type` varchar(255) DEFAULT NULL,
  `context` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_taggings_on_tag_id` (`tag_id`),
  KEY `index_taggings_on_taggable_id_and_taggable_type_and_context` (`taggable_id`,`taggable_type`,`context`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`taggings` (`id`,`tag_id`,`taggable_id`,`tagger_id`,`tagger_type`,`taggable_type`,`context`,`created_at`) VALUES 
 (1,4,1,NULL,NULL,'Post','tags','2010-01-07 04:37:13'),
 (2,5,1,NULL,NULL,'Post','tags','2010-01-07 04:37:13'),
 (3,8,2,NULL,NULL,'Post','tags','2010-01-07 06:37:04');

DROP TABLE IF EXISTS `thelodgedb`.`tags`;
CREATE TABLE  `thelodgedb`.`tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`tags` (`id`,`name`) VALUES 
 (2,'wtf'),
 (4,'design'),
 (5,'drupal'),
 (6,'testing'),
 (7,'oh yeah'),
 (8,'shit'),
 (9,'shit');

DROP TABLE IF EXISTS `thelodgedb`.`users`;
CREATE TABLE  `thelodgedb`.`users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `crypted_password` varchar(255) DEFAULT NULL,
  `password_salt` varchar(255) DEFAULT NULL,
  `persistence_token` varchar(255) DEFAULT NULL,
  `login_count` int(11) DEFAULT NULL,
  `failed_login_count` int(11) DEFAULT NULL,
  `last_request_at` datetime DEFAULT NULL,
  `current_login_at` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `current_login_ip` varchar(255) DEFAULT NULL,
  `last_login_ip` varchar(255) DEFAULT NULL,
  `facebook_uid` bigint(20) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`users` (`id`,`name`,`email`,`created_at`,`updated_at`,`crypted_password`,`password_salt`,`persistence_token`,`login_count`,`failed_login_count`,`last_request_at`,`current_login_at`,`last_login_at`,`current_login_ip`,`last_login_ip`,`facebook_uid`,`role_id`) VALUES 
 (1,'Diego','diego@greyrobot.com','2009-11-02 02:16:55','2010-02-21 09:40:06','e168971354744fd4049ff7fff12a6c88748302676c7504c8b5fc7f77c97c7b825fd5dc2ce69d7e6cfe608f986bb7945070f0b8891ee92d3c69e5209245298b52','CGcLhhpTBjTB8TenD-lB','8a150f35195fd7144727dc3399d46fd183d66f2f9ac0d0eb05e25caddce9f70f64725a5bf37c66fcfe3b608a44564f9e7267f180f174c537a8ba56de3075697d',28,0,'2010-02-21 09:40:06','2010-02-21 09:32:45','2010-02-21 08:37:32','127.0.0.1','127.0.0.1',NULL,NULL),
 (2,'test','test@test.com','2009-12-28 09:19:59','2009-12-28 09:19:59','ba0e2c9c81d33788820429a46ddc9810f4875b6f9a0c847e3b304f774c6e423c98430c9523f8089da77dc5645281d6cbae941393dbfc5853e3380c8b3ca41c3b','08AesnqRaY2dIUtqOGAQ','a2cf0eba74ac4c3d83b2e619c3782124ba1cf74261966a85cd6ec32cb1bf566a75c80baad1740a132dccb66097f6da91f25afceb416ff38a822f518f2d9df5ed',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
 (3,'Luis F. Salazar','luis@greyrobot.com','2009-12-29 04:57:06','2009-12-29 05:50:56','c36102057f17fa7a78bbceb54767d1cf1b610a6519bbc7d1f7128dfdd0a3814eda8ea1d7d3f405a9a514198c2b7a6885e5c39c7e03fae374676ce6e6d0f3d51a','ddxqiqGUd7zuB4poXSGs','5c2ca7b85c6cce8cb3063b56d5da51ee0432a81741d1553da43ffdc05f59d03ed97d9aa4eeb310c63ba92b4b2e3cf0f6cdd30361cf3e3183c85d339d3743c999',1,0,'2009-12-29 05:50:56','2009-12-29 04:57:06',NULL,'127.0.0.1',NULL,NULL,NULL);

DROP TABLE IF EXISTS `thelodgedb`.`views`;
CREATE TABLE  `thelodgedb`.`views` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_name` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `scope` varchar(255) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`views` (`id`,`model_name`,`name`,`description`,`created_at`,`updated_at`,`scope`,`owner_id`) VALUES 
 (1,'post','Blog Rolls','test blog roll','2009-12-25 07:41:03','2009-12-30 18:57:00','',NULL),
 (2,'image','Images','show images','2009-12-25 23:39:05','2010-01-07 06:55:55','gallery',2),
 (4,'comment','Comments','Show comments','2009-12-28 06:41:59','2009-12-28 06:41:59','post',NULL),
 (5,'post','Diego\'s Blog','view of diego\'s blog','2009-12-28 09:55:57','2009-12-28 18:51:40','user',1),
 (6,'link','SubnavLinksView','list links from the SubnavLinks group','2009-12-29 04:11:23','2009-12-29 04:11:23','link_group',1),
 (7,'post','Lucho\'s blog view','View description','2009-12-29 05:11:11','2009-12-29 05:11:11','user',3),
 (8,'block','test','test','2009-12-30 11:33:41','2009-12-30 11:33:41','page',1),
 (9,'tag','Post tags list','Show the current post\'s tags','2010-01-04 04:05:54','2010-01-04 04:05:54','post',NULL);

DROP TABLE IF EXISTS `thelodgedb`.`virtual_models`;
CREATE TABLE  `thelodgedb`.`virtual_models` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model` text,
  `schema` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`virtual_models` (`id`,`model`,`schema`,`created_at`,`updated_at`) VALUES 
 (1,'{\\\"description\\\":\\\"descriptive text\\\",\\\"name\\\":\\\"test\\\"}','{\\\"description\\\":\\\"string\\\",\\\"name\\\":\\\"string\\\"}','2009-12-27 16:54:34','2009-12-27 16:54:34'),
 (2,'{\\\"parent_id\\\":0,\\\"enabled\\\":true,\\\"name\\\":\\\"willy\\\"}','{\\\"parent_id\\\":\\\"integer\\\",\\\"enabled\\\":\\\"boolean\\\",\\\"name\\\":\\\"string\\\"}','2009-12-27 19:31:08','2009-12-27 19:31:08');

DROP TABLE IF EXISTS `thelodgedb`.`widget_galleries`;
CREATE TABLE  `thelodgedb`.`widget_galleries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `widget_id` int(11) DEFAULT NULL,
  `gallery_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`widget_galleries` (`id`,`widget_id`,`gallery_id`,`created_at`,`updated_at`) VALUES 
 (6,NULL,0,'2009-10-27 04:07:50','2009-10-27 23:47:15'),
 (7,NULL,0,'2009-10-27 23:47:15','2009-10-28 01:30:13'),
 (8,NULL,0,'2009-10-28 01:30:13','2009-10-28 01:39:45'),
 (9,1,2,'2009-10-28 01:39:45','2009-10-28 01:40:27');

DROP TABLE IF EXISTS `thelodgedb`.`widgets`;
CREATE TABLE  `thelodgedb`.`widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`widgets` (`id`,`title`,`created_at`,`updated_at`,`content`) VALUES 
 (1,'SlideShow','2009-10-25 20:29:01','2009-10-28 01:31:18','');



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
