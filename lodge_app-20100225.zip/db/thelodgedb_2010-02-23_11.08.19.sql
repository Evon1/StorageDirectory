-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.1.40


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema thelodgedb
--

CREATE DATABASE IF NOT EXISTS thelodgedb;
USE thelodgedb;
CREATE TABLE  `thelodgedb`.`block_forms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `block_id` int(11) DEFAULT NULL,
  `form_id` int(11) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`block_forms` (`id`,`block_id`,`form_id`,`enabled`,`position`,`created_at`,`updated_at`) VALUES 
 (6,14,1,1,NULL,'2009-12-29 17:01:32','2009-12-29 17:01:32'),
 (7,6,2,1,NULL,'2010-01-03 03:07:17','2010-01-03 03:07:17'),
 (8,21,6,1,NULL,'2010-01-04 03:56:37','2010-01-04 03:56:37');
CREATE TABLE  `thelodgedb`.`block_widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `block_id` int(11) DEFAULT NULL,
  `widget_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`block_widgets` (`id`,`block_id`,`widget_id`,`created_at`,`updated_at`) VALUES 
 (1,NULL,0,'2009-10-26 03:23:38','2009-12-25 22:04:02'),
 (2,NULL,0,'2009-10-26 03:24:52','2009-10-27 23:43:57'),
 (3,NULL,0,'2009-10-27 23:43:57','2009-10-27 23:47:51'),
 (4,5,1,'2009-10-27 23:47:51','2009-10-27 23:47:51'),
 (5,1,0,'2009-11-08 19:30:37','2009-11-08 19:30:37'),
 (6,NULL,0,'2009-12-24 01:39:05','2009-12-28 08:00:02'),
 (7,NULL,0,'2009-12-24 03:28:07','2009-12-24 22:36:16'),
 (8,NULL,0,'2009-12-24 22:36:16','2009-12-24 22:37:14'),
 (9,NULL,0,'2009-12-24 22:37:14','2009-12-24 22:39:32'),
 (10,NULL,0,'2009-12-24 22:39:32','2009-12-26 16:45:26'),
 (11,NULL,0,'2009-12-25 22:04:02','2009-12-25 22:10:34'),
 (12,NULL,0,'2009-12-25 22:10:34','2009-12-25 23:11:35'),
 (13,NULL,0,'2009-12-25 23:11:35','2009-12-25 23:12:32'),
 (14,NULL,0,'2009-12-25 23:12:32','2009-12-26 07:15:46'),
 (15,NULL,0,'2009-12-25 23:40:19','2009-12-25 23:40:35'),
 (16,NULL,0,'2009-12-25 23:40:35','2009-12-25 23:41:38'),
 (17,NULL,0,'2009-12-25 23:41:38','2009-12-26 01:11:10'),
 (18,NULL,0,'2009-12-26 01:44:32','2009-12-26 02:01:30'),
 (19,NULL,0,'2009-12-26 02:01:30','2009-12-26 02:04:16'),
 (20,NULL,0,'2009-12-26 02:04:16','2009-12-26 02:04:28'),
 (21,NULL,0,'2009-12-26 02:04:28','2009-12-26 02:39:45'),
 (22,NULL,0,'2009-12-26 02:39:45','2009-12-26 07:28:16'),
 (23,NULL,0,'2009-12-26 03:09:55','2009-12-26 17:59:16'),
 (24,NULL,0,'2009-12-26 03:13:25','2009-12-26 07:28:41'),
 (25,NULL,0,'2009-12-26 07:15:46','2009-12-28 08:20:43'),
 (26,NULL,0,'2009-12-26 07:28:16','2009-12-26 19:05:10'),
 (27,NULL,0,'2009-12-26 07:28:41','2009-12-26 07:34:41'),
 (28,NULL,0,'2009-12-26 07:34:41','2009-12-26 07:42:41'),
 (29,NULL,0,'2009-12-26 07:42:41','2009-12-26 18:59:28'),
 (30,NULL,0,'2009-12-26 16:45:26','2009-12-26 17:50:04'),
 (31,NULL,0,'2009-12-26 17:50:04','2010-01-03 12:03:51'),
 (32,NULL,0,'2009-12-26 17:59:16','2009-12-26 17:59:18'),
 (33,NULL,0,'2009-12-26 17:59:18','2009-12-26 18:17:43'),
 (34,8,0,'2009-12-26 18:17:43','2009-12-26 18:17:43'),
 (35,NULL,0,'2009-12-26 18:59:28','2009-12-28 09:06:16'),
 (36,NULL,0,'2009-12-26 19:05:10','2009-12-26 19:18:39'),
 (37,NULL,0,'2009-12-26 19:18:39','2009-12-26 19:22:09'),
 (38,NULL,0,'2009-12-26 19:22:09','2009-12-26 19:22:37'),
 (39,NULL,0,'2009-12-26 19:22:37','2009-12-26 19:34:04'),
 (40,NULL,0,'2009-12-26 19:34:04','2009-12-26 19:35:50'),
 (41,NULL,0,'2009-12-26 19:35:50','2009-12-28 08:03:30'),
 (42,NULL,0,'2009-12-28 02:21:48','2009-12-28 08:15:01'),
 (43,NULL,0,'2009-12-28 04:58:59','2009-12-28 05:05:55'),
 (44,13,0,'2009-12-28 05:05:55','2009-12-28 05:05:55'),
 (45,NULL,0,'2009-12-28 06:45:21','2009-12-28 07:15:31'),
 (46,NULL,0,'2009-12-28 07:15:31','2009-12-28 07:18:14'),
 (47,NULL,0,'2009-12-28 07:18:14','2009-12-28 07:19:04'),
 (48,NULL,0,'2009-12-28 07:19:04','2009-12-28 07:29:15'),
 (49,NULL,0,'2009-12-28 07:29:15','2009-12-28 07:52:07'),
 (50,NULL,0,'2009-12-28 07:52:07','2009-12-29 16:52:25'),
 (51,NULL,0,'2009-12-28 08:00:02','2009-12-29 14:11:24'),
 (52,NULL,0,'2009-12-28 08:03:30','2010-01-07 07:12:18'),
 (53,NULL,0,'2009-12-28 08:08:36','2009-12-28 08:09:00'),
 (54,NULL,0,'2009-12-28 08:09:00','2009-12-28 08:10:38'),
 (55,NULL,0,'2009-12-28 08:10:38','2009-12-28 09:33:21'),
 (56,10,0,'2009-12-28 08:15:01','2009-12-28 08:15:01'),
 (57,NULL,0,'2009-12-28 08:20:43','2009-12-28 09:38:05'),
 (58,NULL,0,'2009-12-28 09:02:29','2010-01-03 07:01:29'),
 (59,NULL,0,'2009-12-28 09:12:30','2009-12-28 09:13:24'),
 (60,NULL,0,'2009-12-28 09:13:24','2009-12-28 09:16:57'),
 (61,NULL,0,'2009-12-28 09:16:57','2009-12-28 09:18:46'),
 (62,NULL,0,'2009-12-28 09:18:46','2009-12-30 07:18:40'),
 (63,NULL,0,'2009-12-28 09:33:21','2009-12-28 09:34:32'),
 (64,NULL,0,'2009-12-28 09:34:32','2009-12-28 09:35:38'),
 (65,15,0,'2009-12-28 09:35:38','2009-12-28 09:35:38'),
 (66,NULL,0,'2009-12-28 09:38:05','2009-12-29 05:59:29'),
 (67,NULL,0,'2009-12-28 09:57:51','2009-12-29 02:24:31'),
 (68,NULL,0,'2009-12-29 02:24:31','2009-12-29 02:24:41'),
 (69,17,0,'2009-12-29 02:25:13','2009-12-29 02:25:13'),
 (70,18,0,'2009-12-29 04:13:06','2009-12-29 04:13:06'),
 (71,19,0,'2009-12-29 05:19:14','2009-12-29 05:19:14'),
 (72,4,0,'2009-12-29 05:59:29','2009-12-29 05:59:29'),
 (73,20,1,'2009-12-29 08:52:26','2009-12-29 08:52:26'),
 (74,NULL,0,'2009-12-29 14:11:24','2009-12-29 14:28:47'),
 (75,NULL,0,'2009-12-29 14:28:47','2009-12-29 14:56:43'),
 (76,NULL,0,'2009-12-29 14:56:43','2009-12-29 14:57:28'),
 (77,NULL,0,'2009-12-29 14:57:28','2009-12-29 15:00:26'),
 (78,NULL,0,'2009-12-29 15:00:26','2009-12-29 15:05:49'),
 (79,NULL,0,'2009-12-29 15:05:49','2009-12-29 15:06:09'),
 (80,NULL,0,'2009-12-29 15:06:09','2009-12-29 15:13:18'),
 (81,NULL,0,'2009-12-29 15:13:18','2009-12-29 15:13:28'),
 (82,NULL,0,'2009-12-29 15:13:28','2009-12-29 16:00:03'),
 (83,NULL,0,'2009-12-29 16:00:03','2009-12-29 16:02:10'),
 (84,NULL,0,'2009-12-29 16:02:10','2009-12-29 16:02:41'),
 (85,NULL,0,'2009-12-29 16:02:41','2009-12-29 16:04:29'),
 (86,NULL,0,'2009-12-29 16:04:29','2010-01-03 03:07:17'),
 (87,NULL,0,'2009-12-29 16:52:25','2009-12-29 16:53:10'),
 (88,NULL,0,'2009-12-29 16:53:10','2009-12-29 16:53:19'),
 (89,NULL,0,'2009-12-29 16:53:19','2009-12-29 16:55:56'),
 (90,NULL,0,'2009-12-29 16:55:56','2009-12-29 16:57:11'),
 (91,NULL,0,'2009-12-29 16:57:11','2009-12-29 16:59:27'),
 (92,NULL,0,'2009-12-29 16:59:27','2009-12-29 16:59:42'),
 (93,NULL,0,'2009-12-29 16:59:42','2009-12-29 17:01:21'),
 (94,NULL,0,'2009-12-29 17:01:21','2009-12-29 17:01:32'),
 (95,NULL,0,'2009-12-29 17:01:32','2009-12-29 17:05:01'),
 (96,NULL,0,'2009-12-29 17:05:02','2009-12-29 17:05:41'),
 (97,NULL,0,'2009-12-29 17:05:41','2009-12-29 23:11:08'),
 (98,NULL,0,'2009-12-29 23:11:08','2010-01-03 07:16:01'),
 (99,NULL,0,'2009-12-30 07:18:40','2009-12-30 07:19:38'),
 (100,9,0,'2009-12-30 07:19:38','2009-12-30 07:19:38'),
 (101,NULL,0,'2010-01-03 03:07:17','2010-02-23 00:39:21'),
 (102,NULL,0,'2010-01-03 07:01:29','2010-01-03 07:02:15'),
 (103,NULL,0,'2010-01-03 07:02:15','2010-01-03 08:23:29'),
 (104,14,0,'2010-01-03 07:16:01','2010-01-03 07:16:01'),
 (105,NULL,0,'2010-01-03 08:23:29','2010-01-03 08:24:52'),
 (106,NULL,0,'2010-01-03 08:24:52','2010-01-03 08:26:57'),
 (107,NULL,0,'2010-01-03 08:26:57','2010-01-03 08:30:41'),
 (108,NULL,0,'2010-01-03 08:30:41','2010-01-03 08:35:38'),
 (109,NULL,0,'2010-01-03 08:35:38','2010-01-03 08:35:53'),
 (110,NULL,0,'2010-01-03 08:35:53','2010-01-03 09:54:36'),
 (111,NULL,0,'2010-01-03 09:54:36','2010-02-21 08:48:50'),
 (112,NULL,0,'2010-01-03 12:03:51','2010-01-03 18:01:03'),
 (113,NULL,0,'2010-01-03 18:01:03','2010-02-21 08:40:15'),
 (114,NULL,0,'2010-01-04 03:56:37','2010-01-04 04:06:54'),
 (115,21,0,'2010-01-04 04:06:54','2010-01-04 04:06:54'),
 (116,NULL,0,'2010-01-07 07:12:18','2010-02-23 05:57:43'),
 (117,NULL,0,'2010-02-21 08:40:15','2010-02-21 09:01:06'),
 (118,NULL,0,'2010-02-21 08:48:50','2010-02-21 08:49:34'),
 (119,16,0,'2010-02-21 08:49:34','2010-02-21 08:49:34'),
 (120,NULL,0,'2010-02-21 09:01:06','2010-02-21 09:01:13'),
 (121,NULL,0,'2010-02-21 09:01:13','2010-02-23 05:36:39'),
 (122,6,0,'2010-02-23 00:39:21','2010-02-23 00:39:21'),
 (123,NULL,0,'2010-02-23 05:36:39','2010-02-23 05:38:05'),
 (124,NULL,0,'2010-02-23 05:38:05','2010-02-23 05:52:57'),
 (125,NULL,0,'2010-02-23 05:52:57','2010-02-23 06:00:18'),
 (126,7,0,'2010-02-23 05:57:43','2010-02-23 05:57:43'),
 (127,2,0,'2010-02-23 06:00:18','2010-02-23 06:00:18');
CREATE TABLE  `thelodgedb`.`blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `content` text,
  `show_title` tinyint(1) DEFAULT NULL,
  `show_in_all` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`blocks` (`id`,`created_at`,`updated_at`,`title`,`description`,`content`,`show_title`,`show_in_all`) VALUES 
 (2,'2009-10-22 02:26:42','2010-02-23 06:00:18','Footer','HTML for the footer.','<div id=\"twitter\">\r\n	<a href=\"http://twitter.com/\" target=\"_blank\"><img alt=\"Follow Us on Twitter\" src=\"/images/ui/thelodgedb/twitter-icon.png\" /></a></div>\r\n<div id=\"specials\">\r\n	Text LODGE to 69302 for specials and events</div>\r\n<div id=\"facebook\">\r\n	<a href=\"http://facebook.com/\" target=\"_blank\"><img alt=\"Find Us on Facebook\" src=\"/images/ui/thelodgedb/fb-icon.png\" /></a></div>\r\n',0,'footer'),
 (6,'2009-12-24 01:39:05','2010-02-23 00:39:21','Contact Form','Small contact form','',0,''),
 (7,'2009-12-25 23:40:19','2009-12-26 19:05:10','Images','show the images view','',0,''),
 (14,'2009-12-28 06:45:21','2009-12-29 23:11:08','Comments','show the comments view','<a name=\"comments\"></a>',0,''),
 (16,'2009-12-28 09:02:29','2010-02-21 08:49:34','Header','Site logo and address','<h1 id=\"logo\" class=\"accessible_img_link\"><a href=\"#\">The Lodge Beer &amp; Grill</a></h1>\r\n  				<div id=\"address\" class=\"right white\">200 S Federal Highway Boca Raton, FL</div>',0,'header'),
 (21,'2010-01-04 03:56:37','2010-01-04 03:56:37','PostTagger','Post tag form','',0,'');
CREATE TABLE  `thelodgedb`.`blocks_models` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_id` int(11) DEFAULT NULL,
  `model_type` varchar(255) DEFAULT NULL,
  `block_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `place` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `show_title` tinyint(1) DEFAULT NULL,
  `position` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=259 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`blocks_models` (`id`,`model_id`,`model_type`,`block_id`,`created_at`,`updated_at`,`place`,`enabled`,`show_title`,`position`) VALUES 
 (28,1,'Page',NULL,'2009-12-26 02:23:50','2009-12-26 02:23:50','sidebar',NULL,NULL,0),
 (29,1,'Page',NULL,'2009-12-26 02:23:50','2009-12-26 02:23:50','footer',NULL,NULL,0),
 (30,1,'Page',NULL,'2009-12-26 02:23:50','2009-12-26 02:23:50','sidebar',NULL,NULL,0),
 (31,1,'Page',NULL,'2009-12-26 02:23:50','2009-12-26 02:23:50','right',NULL,NULL,0),
 (32,1,'Page',NULL,'2009-12-26 02:23:50','2009-12-26 02:23:50','sidebar',NULL,NULL,0),
 (33,1,'Page',NULL,'2009-12-26 02:23:50','2009-12-26 02:23:50','left',NULL,NULL,0),
 (34,1,'Page',NULL,'2009-12-26 02:23:50','2009-12-26 02:23:50','content_bottom',NULL,NULL,0),
 (35,1,'Page',NULL,'2009-12-26 02:26:12','2009-12-26 02:26:12','content_bottom',NULL,NULL,0),
 (95,3,'Post',14,'2009-12-29 05:05:47','2009-12-29 23:13:02','content_bottom',1,0,0),
 (113,3,'Post',NULL,'2009-12-29 23:13:02','2009-12-29 23:13:02',NULL,0,NULL,0),
 (114,3,'Post',NULL,'2009-12-29 23:13:02','2009-12-29 23:13:02',NULL,0,NULL,0),
 (115,3,'Post',NULL,'2009-12-29 23:13:02','2009-12-29 23:13:02',NULL,0,NULL,0),
 (116,3,'Post',NULL,'2009-12-29 23:13:02','2009-12-29 23:13:02',NULL,0,NULL,0),
 (117,3,'Post',NULL,'2009-12-29 23:13:02','2009-12-29 23:13:02',NULL,0,NULL,0),
 (118,3,'Post',NULL,'2009-12-29 23:13:02','2009-12-29 23:13:02',NULL,0,NULL,0),
 (119,3,'Post',NULL,'2009-12-29 23:13:02','2009-12-29 23:13:02',NULL,0,NULL,0),
 (120,1,'Page',NULL,'2009-12-30 07:39:59','2009-12-30 07:39:59',NULL,0,NULL,0),
 (121,1,'Page',NULL,'2009-12-30 07:39:59','2009-12-30 07:39:59',NULL,0,NULL,0),
 (122,1,'Page',NULL,'2009-12-30 07:39:59','2009-12-30 07:39:59',NULL,0,NULL,0),
 (123,1,'Page',NULL,'2009-12-30 07:39:59','2009-12-30 07:39:59',NULL,0,NULL,0),
 (124,1,'Page',NULL,'2009-12-30 07:39:59','2009-12-30 07:39:59',NULL,0,NULL,0),
 (125,1,'Page',NULL,'2009-12-30 07:39:59','2009-12-30 07:39:59',NULL,0,NULL,0),
 (185,1,'Page',NULL,'2010-02-21 08:52:18','2010-02-21 08:52:18',NULL,0,NULL,0),
 (186,1,'Page',NULL,'2010-02-21 08:52:18','2010-02-21 08:52:18',NULL,0,NULL,0),
 (187,1,'Page',NULL,'2010-02-21 08:52:18','2010-02-21 08:52:18',NULL,0,NULL,0),
 (188,1,'Page',NULL,'2010-02-21 08:52:18','2010-02-21 08:52:18',NULL,0,NULL,0),
 (189,1,'Page',NULL,'2010-02-21 08:52:18','2010-02-21 08:52:18',NULL,0,NULL,0),
 (190,1,'Page',NULL,'2010-02-21 08:52:18','2010-02-21 08:52:18',NULL,0,NULL,0),
 (191,1,'Page',NULL,'2010-02-21 08:58:53','2010-02-21 08:58:53',NULL,0,NULL,0),
 (192,1,'Page',NULL,'2010-02-21 08:58:53','2010-02-21 08:58:53',NULL,0,NULL,0),
 (193,1,'Page',NULL,'2010-02-21 08:58:53','2010-02-21 08:58:53',NULL,0,NULL,0),
 (194,1,'Page',NULL,'2010-02-21 08:58:53','2010-02-21 08:58:53',NULL,0,NULL,0),
 (195,1,'Page',NULL,'2010-02-21 08:58:53','2010-02-21 08:58:53',NULL,0,NULL,0),
 (196,1,'Page',NULL,'2010-02-21 08:58:53','2010-02-21 08:58:53',NULL,0,NULL,0),
 (197,1,'Page',NULL,'2010-02-21 08:58:53','2010-02-21 08:58:53',NULL,0,NULL,0),
 (198,1,'Page',NULL,'2010-02-21 08:59:05','2010-02-21 08:59:05',NULL,0,NULL,0),
 (199,1,'Page',NULL,'2010-02-21 08:59:05','2010-02-21 08:59:05',NULL,0,NULL,0),
 (200,1,'Page',NULL,'2010-02-21 08:59:05','2010-02-21 08:59:05',NULL,0,NULL,0),
 (201,1,'Page',NULL,'2010-02-21 08:59:05','2010-02-21 08:59:05',NULL,0,NULL,0),
 (202,1,'Page',NULL,'2010-02-21 08:59:05','2010-02-21 08:59:05',NULL,0,NULL,0),
 (203,1,'Page',NULL,'2010-02-21 08:59:05','2010-02-21 08:59:05',NULL,0,NULL,0),
 (204,1,'Page',NULL,'2010-02-21 08:59:05','2010-02-21 08:59:05',NULL,0,NULL,0),
 (205,1,'Page',NULL,'2010-02-21 09:13:58','2010-02-21 09:13:58',NULL,0,NULL,0),
 (206,1,'Page',NULL,'2010-02-21 09:13:58','2010-02-21 09:13:58',NULL,0,NULL,0),
 (207,1,'Page',NULL,'2010-02-21 09:13:58','2010-02-21 09:13:58',NULL,0,NULL,0),
 (208,1,'Page',NULL,'2010-02-21 09:13:58','2010-02-21 09:13:58',NULL,0,NULL,0),
 (209,1,'Page',NULL,'2010-02-21 09:13:58','2010-02-21 09:13:58',NULL,0,NULL,0),
 (210,1,'Page',NULL,'2010-02-21 09:13:58','2010-02-21 09:13:58',NULL,0,NULL,0),
 (211,1,'Page',NULL,'2010-02-21 09:13:58','2010-02-21 09:13:58',NULL,0,NULL,0),
 (212,1,'Page',NULL,'2010-02-21 09:17:12','2010-02-21 09:17:12',NULL,0,NULL,0),
 (213,1,'Page',NULL,'2010-02-21 09:17:12','2010-02-21 09:17:12',NULL,0,NULL,0),
 (214,1,'Page',NULL,'2010-02-21 09:17:12','2010-02-21 09:17:12',NULL,0,NULL,0),
 (215,1,'Page',NULL,'2010-02-21 09:17:12','2010-02-21 09:17:12',NULL,0,NULL,0),
 (216,1,'Page',NULL,'2010-02-21 09:17:12','2010-02-21 09:17:12',NULL,0,NULL,0),
 (217,1,'Page',NULL,'2010-02-21 09:17:12','2010-02-21 09:17:12',NULL,0,NULL,0),
 (218,1,'Page',NULL,'2010-02-21 09:17:12','2010-02-21 09:17:12',NULL,0,NULL,0),
 (219,6,'Page',NULL,'2010-02-23 00:08:43','2010-02-23 00:08:43',NULL,0,NULL,0),
 (220,6,'Page',NULL,'2010-02-23 00:08:43','2010-02-23 00:08:43',NULL,0,NULL,0),
 (221,6,'Page',NULL,'2010-02-23 00:08:43','2010-02-23 00:08:43',NULL,0,NULL,0),
 (222,7,'Page',NULL,'2010-02-23 00:23:12','2010-02-23 00:23:12',NULL,0,NULL,0),
 (223,7,'Page',NULL,'2010-02-23 00:23:12','2010-02-23 00:23:12',NULL,0,NULL,0),
 (224,7,'Page',NULL,'2010-02-23 00:23:12','2010-02-23 00:23:12',NULL,0,NULL,0),
 (225,7,'Page',NULL,'2010-02-23 00:23:26','2010-02-23 00:23:26',NULL,0,NULL,0),
 (226,7,'Page',NULL,'2010-02-23 00:23:26','2010-02-23 00:23:26',NULL,0,NULL,0),
 (227,7,'Page',NULL,'2010-02-23 00:23:26','2010-02-23 00:23:26',NULL,0,NULL,0),
 (228,1,'Page',NULL,'2010-02-23 00:26:14','2010-02-23 00:26:14',NULL,0,NULL,0),
 (229,1,'Page',14,'2010-02-23 00:26:14','2010-02-23 00:26:31','',0,0,0),
 (230,1,'Page',NULL,'2010-02-23 00:26:14','2010-02-23 00:26:14',NULL,0,NULL,0),
 (231,1,'Page',NULL,'2010-02-23 00:26:31','2010-02-23 00:26:31',NULL,0,NULL,0),
 (232,1,'Page',NULL,'2010-02-23 00:26:31','2010-02-23 00:26:31',NULL,0,NULL,0),
 (233,8,'Page',NULL,'2010-02-23 00:35:43','2010-02-23 00:35:43',NULL,0,NULL,0),
 (234,8,'Page',NULL,'2010-02-23 00:35:43','2010-02-23 00:35:43',NULL,0,NULL,0),
 (235,8,'Page',NULL,'2010-02-23 00:35:43','2010-02-23 00:35:43',NULL,0,NULL,0),
 (236,9,'Page',NULL,'2010-02-23 00:36:48','2010-02-23 00:36:48',NULL,0,NULL,0),
 (237,9,'Page',NULL,'2010-02-23 00:36:48','2010-02-23 00:36:48',NULL,0,NULL,0),
 (238,9,'Page',NULL,'2010-02-23 00:36:48','2010-02-23 00:36:48',NULL,0,NULL,0),
 (239,10,'Page',NULL,'2010-02-23 00:37:13','2010-02-23 00:37:13',NULL,0,NULL,0),
 (240,10,'Page',NULL,'2010-02-23 00:37:13','2010-02-23 00:37:13',NULL,0,NULL,0),
 (241,10,'Page',NULL,'2010-02-23 00:37:13','2010-02-23 00:37:13',NULL,0,NULL,0),
 (242,10,'Page',6,'2010-02-23 00:39:39','2010-02-23 00:39:39','content_bottom',1,0,0),
 (243,10,'Page',NULL,'2010-02-23 00:39:39','2010-02-23 00:39:39',NULL,0,NULL,0),
 (244,10,'Page',NULL,'2010-02-23 00:39:39','2010-02-23 00:39:39',NULL,0,NULL,0),
 (245,10,'Page',NULL,'2010-02-23 00:39:39','2010-02-23 00:39:39',NULL,0,NULL,0),
 (246,10,'Page',NULL,'2010-02-23 00:40:47','2010-02-23 00:40:47',NULL,0,NULL,0),
 (247,10,'Page',NULL,'2010-02-23 00:40:47','2010-02-23 00:40:47',NULL,0,NULL,0),
 (248,10,'Page',NULL,'2010-02-23 00:40:47','2010-02-23 00:40:47',NULL,0,NULL,0),
 (249,10,'Page',NULL,'2010-02-23 00:41:07','2010-02-23 00:41:07',NULL,0,NULL,0),
 (250,10,'Page',NULL,'2010-02-23 00:41:07','2010-02-23 00:41:07',NULL,0,NULL,0),
 (251,10,'Page',NULL,'2010-02-23 00:41:07','2010-02-23 00:41:07',NULL,0,NULL,0),
 (252,9,'Page',NULL,'2010-02-23 05:38:33','2010-02-23 05:38:33',NULL,0,NULL,0),
 (253,9,'Page',7,'2010-02-23 05:38:33','2010-02-23 05:38:33','content_bottom',1,0,0),
 (254,9,'Page',NULL,'2010-02-23 05:38:33','2010-02-23 05:38:33',NULL,0,NULL,0),
 (255,9,'Page',NULL,'2010-02-23 05:38:33','2010-02-23 05:38:33',NULL,0,NULL,0),
 (256,10,'Page',NULL,'2010-02-23 05:58:47','2010-02-23 05:58:47',NULL,0,NULL,0),
 (257,10,'Page',NULL,'2010-02-23 05:58:47','2010-02-23 05:58:47',NULL,0,NULL,0),
 (258,10,'Page',NULL,'2010-02-23 05:58:47','2010-02-23 05:58:47',NULL,0,NULL,0);
CREATE TABLE  `thelodgedb`.`comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT '',
  `comment` varchar(255) DEFAULT '',
  `created_at` datetime NOT NULL,
  `commentable_id` int(11) NOT NULL DEFAULT '0',
  `commentable_type` varchar(15) NOT NULL DEFAULT '',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_comments_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`comments` (`id`,`title`,`comment`,`created_at`,`commentable_id`,`commentable_type`,`user_id`,`email`) VALUES 
 (25,'Something','to write','2010-02-23 06:05:07',0,'',1,'hacker@urdataz.com');
CREATE TABLE  `thelodgedb`.`fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_type` varchar(255) DEFAULT NULL,
  `field_attributes` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `form_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`fields` (`id`,`field_type`,`field_attributes`,`created_at`,`updated_at`,`form_id`) VALUES 
 (28,'text_field','{\"name\":\"email\",\"title\":\"Your Email\",\"class\":\"email hintable email hintable\"}','2010-01-03 05:18:07','2010-01-03 05:35:21',2),
 (29,'text_field','{\"name\":\"title\",\"title\":\"Subject\",\"class\":\"required hintable required hintable\"}','2010-01-03 05:18:07','2010-01-03 05:35:21',2),
 (30,'text_area','{\"name\":\"comment\",\"title\":\"Message\",\"class\":\"required hintable small_textarea\"}','2010-01-03 05:18:07','2010-01-03 05:36:09',2),
 (37,'text_field','{\"name\":\"email\",\"title\":\"Your Email\",\"class\":\"small_textfield required hintable\"}','2010-01-03 06:12:48','2010-01-03 06:12:48',1),
 (38,'text_area','{\"name\":\"comment\",\"title\":\"Your Thoughts\",\"class\":\"small_textarea required hintable\"}','2010-01-03 06:12:48','2010-01-03 06:12:48',1),
 (39,'text_field','{\"name\":\"name\",\"title\":\"Tags\",\"class\":\"tags_field hintable\"}','2010-01-04 03:42:40','2010-01-04 03:42:40',6);
CREATE TABLE  `thelodgedb`.`forms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `controller` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `scope` varchar(255) DEFAULT NULL,
  `target_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`forms` (`id`,`name`,`description`,`controller`,`action`,`enabled`,`created_at`,`updated_at`,`scope`,`target_id`) VALUES 
 (1,'Share your thoughts','The post comment form','comments','create',1,'2009-12-29 11:18:50','2009-12-29 22:33:44','post',NULL),
 (2,'Contact Form','Sitewide contact form','comments','create',1,'2009-12-29 23:28:05','2010-01-03 00:06:28','',NULL),
 (6,'Post Tag Form','Create tags on a post','tags','create',1,'2010-01-02 22:23:52','2010-01-02 22:23:52','post',NULL);
CREATE TABLE  `thelodgedb`.`galleries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`galleries` (`id`,`title`,`created_at`,`updated_at`,`description`) VALUES 
 (3,'Photos','2010-02-23 05:46:31','2010-02-23 05:46:31','Gallery for the Photos page.');
CREATE TABLE  `thelodgedb`.`gallery_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gallery_id` int(11) DEFAULT NULL,
  `image_id` int(11) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`gallery_images` (`id`,`gallery_id`,`image_id`,`order`,`created_at`,`updated_at`) VALUES 
 (15,3,30,NULL,'2010-02-23 05:47:55','2010-02-23 05:47:55');
CREATE TABLE  `thelodgedb`.`helptexts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(255) DEFAULT NULL,
  `text` text,
  `examples` text,
  `show` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`helptexts` (`id`,`model`,`text`,`examples`,`show`,`created_at`,`updated_at`) VALUES 
 (1,'view','Views define what model records to list, and by what scope. Scoping a view retrieves the records of the view\'s\r\nmodel that are owned by either the active instance (e.g. @page, or @block. in the show action of the model) \r\nor a specific instance as defined by the view\'s owner_id.','<p>\r\n	Example 1:<br />\r\n	A view whose model is &#39;comment&#39; will display all comments. Using scope &#39;post&#39; with no owner_id will retrieve the comments that are owned by the active post instance, if the view is placed in a block or page where that instance variable is set (in this case: @post). For this comment example to work we would have to assign the view to a block and place the block in any post. The view will then render that post&#39;s comments.</p>\r\n<p>\r\n	Example 1:<br />\r\n	A view whose model is &#39;post&#39; will display all posts. Using scope &#39;user&#39; and choosing a user from the resulting dropdown menu in th form, will retrieve all the posts of that specific user. We can then place this view anywhere and it will render all posts by that user if he/she exists, otherwise it will render all posts.</p>\r\n',0,'2009-12-28 20:26:24','2010-02-22 23:48:57'),
 (2,'page','<p>\r\n	Pages are the building blocks of the website. You can author static &#39;Content&#39; for simple pages such as &#39;about&#39;, &#39;contact&#39;, etc. Utilize the built in Rich Text Editor by clicking on &#39;Toggle Editor&#39;. Alternatively, and more preferably, you can build dynamic pages using <a href=\"/blocks\" title=\"The building blocks of pages\">blocks</a>. Select &#39;Show in Nav&#39; to have the page appear in the main site navigation. The &#39;Blocks&#39; list displays available blocks to be placed within regions on the page. A block is &#39;available&#39; when it has not been set to &#39;show in all pages&#39; in the block edit form. A region is a spot on the page that contains blocks, e.g. Banner, Header, Subnav, Footer (and more depending on the layout). To place a block in a region, simply enable its check box and choose a region from its dropdown menu. Adjust the order of the blocks by drag-n-dropping them within the list.</p>\r\n','',0,'2009-12-28 22:37:34','2010-02-23 00:07:37'),
 (3,'block','<p>\r\n	These are the building blocks of pages. You can use them to build pages from scratch or to display common content across the website. Blocks can also be placed in posts. At their simplest, blocks contain static HTML and are used to display content that rarely changes on common areas of the website such as the header, sidebar and footer. Blocks have a special feature called <a href=\"/views\" title=\"Views allow you to display your content in various ways\">Views</a> that allow you to customize the way you display your content. Finally, a block may contain a widget. Currently, only the slideshow widget is supported.</p>\r\n','<p>\r\n	Example 1 - Static content: regions like the header, sidebar, and footer rarely change, so blocks with static HTML are used to display content in these regions.</p>\r\n<p>\r\n	Example 2 - Views: A personal blog page can be achieved by creating a view that lists Posts, scoped by User and has a specific user as the Owner. Then, pop this view in a block and place the block in the Content Bottom of any page. The block will now display posts of that user in a configurable way.</p>\r\n<p>\r\n	Example 3 - Widgets: Blocks can be assigned one widget, currently only the slideshow widget is supported. To create a slideshow, assign a gallery to a slideshow widget.</p>\r\n',0,'2009-12-29 02:51:22','2010-02-21 14:56:03'),
 (4,'helptext','If you\'re here, you probably know what you\'re doing.','',0,'2009-12-29 03:08:53','2009-12-29 03:12:37'),
 (5,'user','You are the user.','<p>\r\n	Example 1: You.</p>\r\n<p>\r\n	Example 2: Me.</p>\r\n',0,'2009-12-29 05:45:32','2010-01-03 11:26:06'),
 (6,'comment','Comments can be made on Pages, Posts, Images, and Users. Simply make a form to create comments on any of these resources, assign the form to a block and place it on a page that displays instances of the resource, e.g \"/posts/23\", \"/pages/2\". ','',0,'2010-01-03 12:54:20','2010-02-23 06:05:27');
CREATE TABLE  `thelodgedb`.`images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `image_file_name` varchar(255) DEFAULT NULL,
  `image_content_type` varchar(255) DEFAULT NULL,
  `image_file_size` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `description` text,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`images` (`id`,`title`,`image_file_name`,`image_content_type`,`image_file_size`,`created_at`,`updated_at`,`user_id`,`description`,`content`) VALUES 
 (30,'Woohoo','292198367_360255368f.jpg','image/jpeg',47202,'2010-02-23 05:47:55','2010-02-23 05:47:55',NULL,NULL,NULL);
CREATE TABLE  `thelodgedb`.`link_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`link_groups` (`id`,`name`,`description`,`created_at`,`updated_at`) VALUES 
 (1,'SubnavLinks','Links for the subnav','2009-12-29 03:45:32','2009-12-29 03:45:32');
CREATE TABLE  `thelodgedb`.`links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `relative` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `link_group_id` int(11) DEFAULT NULL,
  `resource` varchar(255) DEFAULT NULL,
  `target_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
CREATE TABLE  `thelodgedb`.`models_views` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `view_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `model_type` varchar(255) DEFAULT NULL,
  `order` varchar(255) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `limit` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `view_type` varchar(255) DEFAULT NULL,
  `fields` text,
  `enabled` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`models_views` (`id`,`view_id`,`model_id`,`model_type`,`order`,`position`,`limit`,`created_at`,`updated_at`,`view_type`,`fields`,`enabled`) VALUES 
 (3,2,7,'Block','updated_at DESC',NULL,NULL,'2009-12-26 02:04:28','2010-02-23 05:57:43','box','id, title, created_at, description, content',1),
 (12,4,14,'Block','created_at DESC',NULL,NULL,'2009-12-29 17:05:41','2010-01-03 07:16:01','blog_roll','id, title, comment, created_at, commentable_id, user_id, email',1),
 (13,9,21,'Block','updated_at DESC',NULL,NULL,'2010-01-04 04:06:54','2010-01-04 04:06:54','list','id, name',1);
CREATE TABLE  `thelodgedb`.`pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `show_in_nav` tinyint(1) DEFAULT NULL,
  `content` text,
  `description` text,
  `show_title` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`pages` (`id`,`title`,`parent_id`,`url`,`created_at`,`updated_at`,`show_in_nav`,`content`,`description`,`show_title`) VALUES 
 (1,'Home',NULL,'home/','2009-10-22 01:29:50','2010-02-23 00:26:14',1,'<div class=\"center\">\r\n	<h2 class=\"white\">\r\n		Our Specials</h2>\r\n	<p>\r\n		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n</div>\r\n','Content and HTML for the home page.',0),
 (6,'Beer & Wine Menu',NULL,NULL,'2010-02-23 00:08:43','2010-02-23 00:08:43',1,'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','You guessed it... The beer and wine menu',0),
 (7,'Food Menu',NULL,NULL,'2010-02-23 00:23:12','2010-02-23 00:23:26',1,'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','Uh Huh, da food.',1),
 (8,'Events',NULL,NULL,'2010-02-23 00:35:43','2010-02-23 00:35:43',1,'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','List upcoming events',1),
 (9,'Photos',NULL,NULL,'2010-02-23 00:36:48','2010-02-23 00:36:48',1,'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.','Image gallery',0),
 (10,'Contact',NULL,NULL,'2010-02-23 00:37:13','2010-02-23 05:58:47',1,'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ','Contact form.',0);
CREATE TABLE  `thelodgedb`.`permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resource` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `scope` varchar(255) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`permissions` (`id`,`resource`,`action`,`scope`,`role_id`,`created_at`,`updated_at`) VALUES 
 (1,'posts','create',NULL,2,'2010-01-03 23:51:54','2010-01-04 02:57:00'),
 (3,'posts','read',NULL,2,'2010-01-04 02:57:00','2010-01-04 02:57:00');
CREATE TABLE  `thelodgedb`.`posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `user_id` int(11) DEFAULT NULL,
  `published` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `comments_count` int(11) DEFAULT '0',
  `comments_enabled` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`posts` (`id`,`title`,`content`,`user_id`,`published`,`created_at`,`updated_at`,`comments_count`,`comments_enabled`) VALUES 
 (3,'Test post.','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sagittis ante sed quam dapibus pellentesque. Sed condimentum rhoncus egestas. Phasellus sagittis lorem sed turpis condimentum vulputate. Vivamus urna libero, ullamcorper in interdum eu, consequat ut felis. Etiam at ultricies neque. Vestibulum faucibus, nibh sit amet aliquet imperdiet, augue metus tempor dolor, in euismod sapien justo a erat. Maecenas elit nisi, dapibus quis dictum sed, luctus id lectus. Duis accumsan lobortis auctor. Nam tempor odio sit amet elit vestibulum nec consequa.',3,1,'2009-12-29 05:05:47','2009-12-29 05:05:47',1,NULL);
CREATE TABLE  `thelodgedb`.`roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`roles` (`id`,`title`,`created_at`,`updated_at`) VALUES 
 (1,'Admin','2010-01-03 23:49:31','2010-01-03 23:49:31'),
 (2,'Writer','2010-01-03 23:49:47','2010-01-03 23:49:47'),
 (3,'Subscriber','2010-01-03 23:49:59','2010-01-03 23:49:59');
CREATE TABLE  `thelodgedb`.`schema_migrations` (
  `version` varchar(255) NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`schema_migrations` (`version`) VALUES 
 ('20091014021209'),
 ('20091014225335'),
 ('20091014225552'),
 ('20091014230855'),
 ('20091015195645'),
 ('20091015200226'),
 ('20091015200506'),
 ('20091015200950'),
 ('20091015232818'),
 ('20091022045224'),
 ('20091022055430'),
 ('20091023043448'),
 ('20091024234522'),
 ('20091025194246'),
 ('20091026012136'),
 ('20091026033106'),
 ('20091026044725'),
 ('20091026044840'),
 ('20091026045218'),
 ('20091026050451'),
 ('20091027032613'),
 ('20091101233717'),
 ('20091102010603'),
 ('20091102020639'),
 ('20091103020329'),
 ('20091103021236'),
 ('20091103021509'),
 ('20091103033125'),
 ('20091103035431'),
 ('20091224022844'),
 ('20091225054127'),
 ('20091225073949'),
 ('20091225185949'),
 ('20091225190523'),
 ('20091225191132'),
 ('20091225223106'),
 ('20091226162714'),
 ('20091226163306'),
 ('20091226174507'),
 ('20091226190656'),
 ('20091226232840'),
 ('20091228053428'),
 ('20091228061033'),
 ('20091228063338'),
 ('20091228161508'),
 ('20091228200352'),
 ('20091228233644'),
 ('20091228235420'),
 ('20091229032609'),
 ('20091229033215'),
 ('20091229094516'),
 ('20091229125341'),
 ('20091229133234'),
 ('20091229150821'),
 ('20091229202439'),
 ('20091229205600'),
 ('20091229211742'),
 ('20091230043506'),
 ('20100103015729'),
 ('20100103015807'),
 ('20100103022328'),
 ('20100103022640'),
 ('20100103090350'),
 ('20100103215134'),
 ('20100107070421'),
 ('20100107073354'),
 ('20100115031926'),
 ('20100221085730');
CREATE TABLE  `thelodgedb`.`suggestions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `controller` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
CREATE TABLE  `thelodgedb`.`taggings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_id` int(11) DEFAULT NULL,
  `taggable_id` int(11) DEFAULT NULL,
  `tagger_id` int(11) DEFAULT NULL,
  `tagger_type` varchar(255) DEFAULT NULL,
  `taggable_type` varchar(255) DEFAULT NULL,
  `context` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_taggings_on_tag_id` (`tag_id`),
  KEY `index_taggings_on_taggable_id_and_taggable_type_and_context` (`taggable_id`,`taggable_type`,`context`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
CREATE TABLE  `thelodgedb`.`tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`tags` (`id`,`name`) VALUES 
 (2,'wtf'),
 (4,'design'),
 (5,'drupal'),
 (6,'testing'),
 (7,'oh yeah'),
 (8,'shit'),
 (9,'shit');
CREATE TABLE  `thelodgedb`.`users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `crypted_password` varchar(255) DEFAULT NULL,
  `password_salt` varchar(255) DEFAULT NULL,
  `persistence_token` varchar(255) DEFAULT NULL,
  `login_count` int(11) DEFAULT NULL,
  `failed_login_count` int(11) DEFAULT NULL,
  `last_request_at` datetime DEFAULT NULL,
  `current_login_at` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `current_login_ip` varchar(255) DEFAULT NULL,
  `last_login_ip` varchar(255) DEFAULT NULL,
  `facebook_uid` bigint(20) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`users` (`id`,`name`,`email`,`created_at`,`updated_at`,`crypted_password`,`password_salt`,`persistence_token`,`login_count`,`failed_login_count`,`last_request_at`,`current_login_at`,`last_login_at`,`current_login_ip`,`last_login_ip`,`facebook_uid`,`role_id`) VALUES 
 (1,'Diego','diego@greyrobot.com','2009-11-02 02:16:55','2010-02-23 07:42:41','e168971354744fd4049ff7fff12a6c88748302676c7504c8b5fc7f77c97c7b825fd5dc2ce69d7e6cfe608f986bb7945070f0b8891ee92d3c69e5209245298b52','CGcLhhpTBjTB8TenD-lB','8a150f35195fd7144727dc3399d46fd183d66f2f9ac0d0eb05e25caddce9f70f64725a5bf37c66fcfe3b608a44564f9e7267f180f174c537a8ba56de3075697d',29,0,'2010-02-23 07:42:41','2010-02-21 14:48:16','2010-02-21 09:32:45','127.0.0.1','127.0.0.1',NULL,NULL),
 (2,'test','test@test.com','2009-12-28 09:19:59','2009-12-28 09:19:59','ba0e2c9c81d33788820429a46ddc9810f4875b6f9a0c847e3b304f774c6e423c98430c9523f8089da77dc5645281d6cbae941393dbfc5853e3380c8b3ca41c3b','08AesnqRaY2dIUtqOGAQ','a2cf0eba74ac4c3d83b2e619c3782124ba1cf74261966a85cd6ec32cb1bf566a75c80baad1740a132dccb66097f6da91f25afceb416ff38a822f518f2d9df5ed',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
 (3,'Luis F. Salazar','luis@greyrobot.com','2009-12-29 04:57:06','2009-12-29 05:50:56','c36102057f17fa7a78bbceb54767d1cf1b610a6519bbc7d1f7128dfdd0a3814eda8ea1d7d3f405a9a514198c2b7a6885e5c39c7e03fae374676ce6e6d0f3d51a','ddxqiqGUd7zuB4poXSGs','5c2ca7b85c6cce8cb3063b56d5da51ee0432a81741d1553da43ffdc05f59d03ed97d9aa4eeb310c63ba92b4b2e3cf0f6cdd30361cf3e3183c85d339d3743c999',1,0,'2009-12-29 05:50:56','2009-12-29 04:57:06',NULL,'127.0.0.1',NULL,NULL,NULL);
CREATE TABLE  `thelodgedb`.`views` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_name` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `scope` varchar(255) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`views` (`id`,`model_name`,`name`,`description`,`created_at`,`updated_at`,`scope`,`owner_id`) VALUES 
 (2,'image','Images','show images','2009-12-25 23:39:05','2010-02-23 05:57:20','gallery',3),
 (4,'comment','Comments','Show comments','2009-12-28 06:41:59','2009-12-28 06:41:59','post',NULL),
 (8,'block','test','test','2009-12-30 11:33:41','2009-12-30 11:33:41','page',1),
 (9,'tag','Post tags list','Show the current post\'s tags','2010-01-04 04:05:54','2010-01-04 04:05:54','post',NULL);
CREATE TABLE  `thelodgedb`.`virtual_models` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model` text,
  `schema` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`virtual_models` (`id`,`model`,`schema`,`created_at`,`updated_at`) VALUES 
 (1,'{\\\"description\\\":\\\"descriptive text\\\",\\\"name\\\":\\\"test\\\"}','{\\\"description\\\":\\\"string\\\",\\\"name\\\":\\\"string\\\"}','2009-12-27 16:54:34','2009-12-27 16:54:34'),
 (2,'{\\\"parent_id\\\":0,\\\"enabled\\\":true,\\\"name\\\":\\\"willy\\\"}','{\\\"parent_id\\\":\\\"integer\\\",\\\"enabled\\\":\\\"boolean\\\",\\\"name\\\":\\\"string\\\"}','2009-12-27 19:31:08','2009-12-27 19:31:08');
CREATE TABLE  `thelodgedb`.`widget_galleries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `widget_id` int(11) DEFAULT NULL,
  `gallery_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`widget_galleries` (`id`,`widget_id`,`gallery_id`,`created_at`,`updated_at`) VALUES 
 (6,NULL,0,'2009-10-27 04:07:50','2009-10-27 23:47:15'),
 (7,NULL,0,'2009-10-27 23:47:15','2009-10-28 01:30:13'),
 (8,NULL,0,'2009-10-28 01:30:13','2009-10-28 01:39:45');
CREATE TABLE  `thelodgedb`.`widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
INSERT INTO `thelodgedb`.`widgets` (`id`,`title`,`created_at`,`updated_at`,`content`) VALUES 
 (1,'SlideShow','2009-10-25 20:29:01','2009-10-28 01:31:18','');



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
